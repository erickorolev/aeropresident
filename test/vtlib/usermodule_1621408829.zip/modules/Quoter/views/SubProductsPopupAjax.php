<?php

class Quotes_SubProductsPopupAjax_View extends Inventory_SubProductsPopupAjax_View
{
}

?>