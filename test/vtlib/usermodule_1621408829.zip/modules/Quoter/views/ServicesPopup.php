<?php

class Quoter_ServicesPopup_View extends Inventory_ServicesPopup_View
{
}

?>