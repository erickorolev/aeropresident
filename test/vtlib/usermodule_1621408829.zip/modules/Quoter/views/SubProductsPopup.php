<?php

class Quotes_SubProductsPopup_View extends Inventory_SubProductsPopup_View
{
}

?>