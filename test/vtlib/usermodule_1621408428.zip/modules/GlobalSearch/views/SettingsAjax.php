<?php

class GlobalSearch_SettingsAjax_View extends Vtiger_IndexAjax_View
{
    public function process(Vtiger_Request $request)
    {
        global $adb;
        $viewer = $this->getViewer($request);
        $moduleName = $request->get("search_module");
        $module = $request->getModule();
        $moduleModel = Vtiger_Module_Model::getInstance($moduleName);
        $recordStructureInstance = Vtiger_RecordStructure_Model::getInstanceForModule($moduleModel);
        $viewer->assign("RECORD_STRUCTURE_MODEL", $recordStructureInstance);
        $recordStructure = $recordStructureInstance->getStructure();
        if (in_array($moduleName, getInventoryModules())) {
            $itemsBlock = "LBL_ITEM_DETAILS";
            unset($recordStructure[$itemsBlock]);
        }
        $viewer->assign("RECORD_STRUCTURE", $recordStructure);
        if ($moduleName == "Calendar") {
            $relatedModuleName = "Events";
            $relatedModuleModel = Vtiger_Module_Model::getInstance($relatedModuleName);
            $relatedRecordStructureInstance = Vtiger_RecordStructure_Model::getInstanceForModule($relatedModuleModel);
            $eventBlocksFields = $relatedRecordStructureInstance->getStructure();
            $viewer->assign("EVENT_RECORD_STRUCTURE_MODEL", $relatedRecordStructureInstance);
            $viewer->assign("EVENT_RECORD_STRUCTURE", $eventBlocksFields);
        }
        $selectedFields = array();
        $selectedFields_show = array();
        $rs = $adb->pquery("SELECT * FROM `global_search_modules` WHERE module=?", array($moduleName));
        if (0 < $adb->num_rows($rs)) {
            $viewer->assign("ACTIVE", $adb->query_result($rs, 0, "active"));
            $rs_field = $adb->pquery("SELECT * FROM `global_search_fields` WHERE module=? ORDER BY id ASC", array($moduleName));
            if (0 < $adb->num_rows($rs_field)) {
                while ($row = $adb->fetch_array($rs_field)) {
                    if (!empty($row["fieldname"])) {
                        $selectedFields[] = $row["fieldname"];
                    }
                    if (!empty($row["fieldname_show"])) {
                        $selectedFields_show[] = $row["fieldname_show"];
                    }
                }
            }
        }
        $sql = "SELECT * FROM `global_search_quick_search_settings` WHERE module = ?;";
        $re = $adb->pquery($sql, array($moduleName));
        $enable_in_quick_search = 0;
        if (0 < $adb->num_rows($re)) {
            $enable_in_quick_search = $adb->query_result($re, 0, "enabled");
            $quick_search_fields_search = $adb->query_result($re, 0, "search_fields");
            $quick_search_fields_search = explode(",", $quick_search_fields_search);
            $quick_search_fields_show = $adb->query_result($re, 0, "show_fields");
            $quick_search_fields_show = explode(",", $quick_search_fields_show);
        }
        $viewer->assign("ENABLE_IN_QUICK_SEARCH", $enable_in_quick_search);
        $viewer->assign("QUICK_SEARCH_FIELDS_SHOW", $quick_search_fields_show);
        $viewer->assign("QUICK_SEARCH_FIELDS_SEARCH", $quick_search_fields_search);
        $viewer->assign("SELECTED_FIELDS", $selectedFields);
        $viewer->assign("SELECTEDFIELDS_SHOW", $selectedFields_show);
        $viewer->assign("USER_MODEL", Users_Record_Model::getCurrentUserModel());
        $viewer->assign("SOURCE_MODULE", $moduleName);
        $viewer->assign("SOURCE_MODULE_MODEL", $moduleModel);
        echo $viewer->view("SelectedFields.tpl", $module, true);
    }
}

?>