<?php

class GlobalSearch_SearchResults_View extends Vtiger_Index_View
{
    public function __construct()
    {
        parent::__construct();
    }
   
    public function checkPermission(Vtiger_Request $request)
    {
        return true;
    }
    public function process(Vtiger_Request $request)
    {
        $viewer = $this->getViewer($request);
        $moduleName = $request->getModule();
        $moduleModel = Vtiger_Module_Model::getInstance($moduleName);
        $this->viewName = $request->get("viewname");
        $this->initializeListViewContents($request, $viewer);
        $viewer->assign("VIEW", $request->get("view"));
        $viewer->assign("MODULE_MODEL", $moduleModel);
        $viewer->assign("CURRENT_USER_MODEL", Users_Record_Model::getCurrentUserModel());
        if ($request->get("search_module") != "" && $request->get("search_module") != "undefined" && $request->get("ajax") == 1) {
            $viewer->view("ListViewContents.tpl", $moduleName);
        } else {
            $viewer->view("ListView.tpl", $moduleName);
        }
    }
    public function initializeListViewContents(Vtiger_Request $request, Vtiger_Viewer $viewer)
    {
        global $adb;
        global $vtiger_current_version;
        $debug = $request->get("debug");
        $search_results = array();
        $pagingModels = array();
        $record_comments = array();
        $searchVals = explode(" ", $request->get("value"));
        $search_module = $request->get("search_module");
        $search_type = $request->get("search_type");
        $sql = "SELECT * FROM global_search_method";
        $re = $adb->pquery($sql, array());
        if (0 < $adb->num_rows($re)) {
            $search_method = $adb->query_result($re, 0, "search_method");
        }
        $searchQuery = "SELECT global_search_modules.*\n                FROM `global_search_modules`\n                INNER JOIN vtiger_tab ON vtiger_tab.`name`=global_search_modules.module\n                WHERE active='1' AND presence<>1 AND isentitytype = '1'";
        if ($search_module != "" && $search_module != "undefined") {
            $searchQuery .= " AND global_search_modules.module='" . $search_module . "'";
        }
        $searchQuery .= " ORDER BY global_search_modules.sequence";
        $rs = $adb->pquery($searchQuery, array());
        if (0 < $adb->num_rows($rs)) {
            while ($row = $adb->fetch_array($rs)) {
                $pagingModel = new Vtiger_Paging_Model();
                $current_page = $request->get("page") ? $request->get("page") : 1;
                $pagingModel->set("page", $current_page);
                $orderBy = $request->get("orderby");
                $sortOrder = $request->get("sortorder");
                $queryFields = array();
                $search_module = $row["module"];
                if (in_array($search_module, array("ANCustomers", "ANPaymentProfile", "ANTransactions", "DuplicateCheckMerge"))) {
                    continue;
                }
                $presenceFields = $this->getPresenceFields($search_module);
                $user = Users_Record_Model::getCurrentUserModel();
                $userPrivilegesModel = Users_Privileges_Model::getCurrentUserPrivilegesModel();
                $moduleFocus = CRMEntity::getInstance($search_module);
                $moduleModel = Vtiger_Module_Model::getInstance($search_module);
                $permission = $userPrivilegesModel->hasModulePermission($moduleModel->getId());
                if ($permission) {
                    if (version_compare($vtiger_current_version, "7.0.0", "<")) {
                        $queryGenerator = new QueryGenerator($search_module, $user);
                    } else {
                        $queryGenerator = new EnhancedQueryGenerator($search_module, $user);
                    }
                    $referenceFieldInfoList = $queryGenerator->getReferenceFieldInfoList();
                    $referenceFieldList = $queryGenerator->getReferenceFieldList();
                    $modulePhoneFields = $this->getPhoneFields($search_module);
                    $moduleFieldList = $moduleModel->getFields();
                    $queryFields[] = "id";
                    $rsFields = $adb->pquery("SELECT * FROM `global_search_fields` WHERE module=? AND fieldname <> '' AND fieldname IS NOT NULL ORDER BY id", array($search_module));
                    $numRows = $adb->num_rows($rsFields);
                    if ($numRows == 0) {
                        $sql_default_view = "SELECT DISTINCT\n                            vtiger_cvcolumnlist.columnname AS fieldname\n                        FROM\n                            `vtiger_cvcolumnlist`\n                        INNER JOIN (\n                            SELECT\n                                *\n                            FROM\n                                vtiger_customview\n                            WHERE\n                                viewname = 'All' AND vtiger_customview.entitytype = '" . $search_module . "'\n                            ORDER BY\n                                cvid ASC\n                            LIMIT 1\n                        ) vtiger_customview ON vtiger_customview.cvid = vtiger_cvcolumnlist.cvid\n                        ORDER BY\n                            columnindex";
                        $rsFields = $adb->pquery($sql_default_view, array());
                        $numRows = $adb->num_rows($rsFields);
                    }
                    $i = 0;
                    $phoneFields = array();
                    if (0 < $numRows) {
                        $rowFields_array = array();
                        while ($row = $adb->fetch_array($rsFields)) {
                            $rowFields_array[] = $row;
                        }
                        $search_value = trim($request->get("value"));
                        if (strpos($search_value, ";") !== false && 1 < count(explode(";", $search_value))) {
                            $search_value = explode(";", $search_value);
                            $j = 0;
                            foreach ($search_value as $value) {
                                if (0 < $j) {
                                    $queryGenerator->addConditionGlue("and");
                                }
                                if (trim($value) != "") {
                                    $queryGenerator->startGroup("");
                                }
                                $k = 0;
                                foreach ($rowFields_array as $rowFields) {
                                    $fieldDetails = explode(":", $rowFields["fieldname"]);
                                    if (in_array($fieldDetails[2], $presenceFields)) {
                                        if (in_array($fieldDetails[2], $referenceFieldList) && count($referenceFieldInfoList[$fieldDetails[2]]) == 0) {
                                            continue;
                                        }
                                        $queryFields[] = $fieldDetails[2];
                                        if (empty($fieldDetails[2]) && $fieldDetails[1] == "crmid" && $fieldDetails[0] == "vtiger_crmentity") {
                                            $name = $queryGenerator->getSQLColumn("id");
                                        } else {
                                            $name = $fieldDetails[2];
                                        }
                                        $fieldModel = $moduleFieldList[$name];
                                        if (empty($fieldModel) || !$fieldModel->isViewableInDetailView()) {
                                            continue;
                                        }
                                        if (in_array($name, array_keys($modulePhoneFields))) {
                                            $searchKey = preg_replace("/[^A-Za-z0-9]/", "", trim($value));
                                            if ($searchKey != "") {
                                                $phoneFields[] = $modulePhoneFields[$name] . "." . $name;
                                                if (0 < $k) {
                                                    $queryGenerator->addConditionGlue("or");
                                                }
                                                $queryGenerator->addCondition($name, $searchKey, "c");
                                                $k++;
                                            }
                                        } else {
                                            $searchKey = trim($value);
                                            if (!empty($searchKey)) {
                                                if ($fieldDetails[4] == "D" || $fieldDetails[4] == "DT" || $fieldDetails[4] == "T") {
                                                    $searchValue = DateTimeField::convertToDBFormat($searchKey);
                                                    if (strtotime($searchValue)) {
                                                        if (0 < $k) {
                                                            $queryGenerator->addConditionGlue("or");
                                                        }
                                                        $queryGenerator->addCondition($name, $searchValue, "e");
                                                        $k++;
                                                    }
                                                } else {
                                                    if (($fieldDetails[4] == "N" || $fieldDetails[4] == "NN" || $fieldDetails[4] == "I") && is_numeric($searchKey)) {
                                                        if (0 < $k) {
                                                            $queryGenerator->addConditionGlue("or");
                                                        }
                                                        $queryGenerator->addCondition($name, $searchKey, "e");
                                                        $k++;
                                                    } else {
                                                        if ($fieldDetails[4] != "N" && $fieldDetails[4] != "NN" && $fieldDetails[4] != "I") {
                                                            if (0 < $k) {
                                                                $queryGenerator->addConditionGlue("or");
                                                            }
                                                            $queryGenerator->addCondition($name, $searchKey, "c");
                                                            $k++;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                if (trim($value) != "") {
                                    $queryGenerator->endGroup();
                                }
                                $j++;
                            }
                        } else {
                            if (trim($request->get("value")) != "") {
                                $queryGenerator->startGroup("");
                            }
                            foreach ($rowFields_array as $rowFields) {
                                $fieldDetails = explode(":", $rowFields["fieldname"]);
                                if (in_array($fieldDetails[2], $presenceFields)) {
                                    if (in_array($fieldDetails[2], $referenceFieldList) && count($referenceFieldInfoList[$fieldDetails[2]]) == 0) {
                                        continue;
                                    }
                                    $queryFields[] = $fieldDetails[2];
                                    if (empty($fieldDetails[2]) && $fieldDetails[1] == "crmid" && $fieldDetails[0] == "vtiger_crmentity") {
                                        $name = $queryGenerator->getSQLColumn("id");
                                    } else {
                                        $name = $fieldDetails[2];
                                    }
                                    $fieldModel = $moduleFieldList[$name];
                                    if (empty($fieldModel) || !$fieldModel->isViewableInDetailView()) {
                                        continue;
                                    }
                                    if (in_array($name, array_keys($modulePhoneFields))) {
                                        $searchKey = preg_replace("/[^A-Za-z0-9,]/", "", trim($request->get("value")));
                                        if ($searchKey != "") {
                                            $phoneFields[] = $modulePhoneFields[$name] . "." . $name;
                                            if (0 < $i) {
                                                $queryGenerator->addConditionGlue("or");
                                            }
                                            $queryGenerator->addCondition($name, $searchKey, "c");
                                            $i++;
                                        }
                                    } else {
                                        $searchKey = trim($request->get("value"));
                                        if (!empty($searchKey)) {
                                            if ($fieldDetails[4] == "D" || $fieldDetails[4] == "DT" || $fieldDetails[4] == "T") {
                                                $searchValue = DateTimeField::convertToDBFormat($searchKey);
                                                if (strtotime($searchValue)) {
                                                    if (0 < $i) {
                                                        $queryGenerator->addConditionGlue("or");
                                                    }
                                                    $queryGenerator->addCondition($name, $searchValue, "e");
                                                    $i++;
                                                }
                                            } else {
                                                if (($fieldDetails[4] == "N" || $fieldDetails[4] == "NN" || $fieldDetails[4] == "I") && is_numeric($searchKey)) {
                                                    if (0 < $i) {
                                                        $queryGenerator->addConditionGlue("or");
                                                    }
                                                    $queryGenerator->addCondition($name, $searchKey, "e");
                                                    $i++;
                                                } else {
                                                    if ($fieldDetails[4] != "N" && $fieldDetails[4] != "NN" && $fieldDetails[4] != "I") {
                                                        if (0 < $i) {
                                                            $queryGenerator->addConditionGlue("or");
                                                        }
                                                        $queryGenerator->addCondition($name, $searchKey, "c");
                                                        $i++;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            if (trim($request->get("value")) != "") {
                                $queryGenerator->endGroup();
                            }
                            $customGlobalSearchConditions = $moduleModel->customGlobalSearchCondition;
                            if (!empty($customGlobalSearchConditions)) {
                                foreach ($customGlobalSearchConditions as $customCondition) {
                                    $queryGenerator->addCondition($customCondition[0], $customCondition[1], $customCondition[2], $customCondition[3]);
                                }
                            }
                        }
                    }
                    if (!empty($search_type) && $search_type == "vt_standard") {
                        $viewer->assign("SEARCH_TYPE", $search_type);
                        $search_params = $request->get("search_params");
                        if (!empty($search_params)) {
                            $search_params_str = json_encode($search_params);
                            $viewer->assign("SEARCH_PARAMS", $search_params_str);
                            if (empty($search_params[1])) {
                                unset($search_params[1]);
                            }
                            if (!is_array($search_params)) {
                                $search_params = urldecode($search_params);
                                $search_params = json_decode($search_params);
                                if (empty($search_params[1])) {
                                    unset($search_params[1]);
                                }
                            }
                            $advFilterList = Vtiger_Util_Helper::transferListSearchParamsToFilterCondition($search_params, $moduleModel);
                            if (is_array($advFilterList) && 0 < count($advFilterList)) {
                                vimport("~~/modules/CustomView/CustomView.php");
                                $customView = new CustomView($search_module);
                                $dateSpecificConditions = $customView->getStdFilterConditions();
                                foreach ($advFilterList as $groupindex => $groupcolumns) {
                                    $filtercolumns = $groupcolumns["columns"];
                                    if (0 < count($filtercolumns)) {
                                        $queryGenerator->startGroup("");
                                        foreach ($filtercolumns as $index => $filter) {
                                            $specialDateTimeConditions = Vtiger_Functions::getSpecialDateTimeCondtions();
                                            $nameComponents = explode(":", $filter["columnname"]);
                                            if (empty($nameComponents[2]) && $nameComponents[1] == "crmid" && $nameComponents[0] == "vtiger_crmentity") {
                                                $name = $queryGenerator->getSQLColumn("id");
                                            } else {
                                                $name = $nameComponents[2];
                                            }
                                            if (($nameComponents[4] == "D" || $nameComponents[4] == "DT") && in_array($filter["comparator"], $dateSpecificConditions)) {
                                                $filter["stdfilter"] = $filter["comparator"];
                                                $valueComponents = explode(",", $filter["value"]);
                                                if ($filter["comparator"] == "custom") {
                                                    $filter["startdate"] = DateTimeField::convertToDBFormat($valueComponents[0]);
                                                    $filter["enddate"] = DateTimeField::convertToDBFormat($valueComponents[1]);
                                                }
                                                $dateFilterResolvedList = $customView->resolveDateFilterValue($filter);
                                                $value[] = $queryGenerator->fixDateTimeValue($name, $dateFilterResolvedList["startdate"]);
                                                $value[] = $queryGenerator->fixDateTimeValue($name, $dateFilterResolvedList["enddate"], false);
                                                $queryGenerator->addCondition($name, $value, "BETWEEN");
                                            } else {
                                                if (($nameComponents[4] == "D" || $nameComponents[4] == "DT") && in_array($filter["comparator"], $specialDateTimeConditions)) {
                                                    $values = EnhancedQueryGenerator::getSpecialDateConditionValue($filter["comparator"], $filter["value"], $nameComponents[4], true);
                                                    $queryGenerator->addCondition($name, $values["date"], $values["comparator"]);
                                                } else {
                                                    $queryGenerator->addCondition($name, $filter["value"], $filter["comparator"]);
                                                }
                                            }
                                            $columncondition = $filter["column_condition"];
                                            if (!empty($columncondition)) {
                                                $queryGenerator->addConditionGlue($columncondition);
                                            }
                                        }
                                        $queryGenerator->endGroup();
                                        $groupConditionGlue = $groupcolumns["condition"];
                                        if (!empty($groupConditionGlue)) {
                                            $queryGenerator->addConditionGlue($groupConditionGlue);
                                        }
                                    }
                                }
                            }
                        }
                    }
                    $columnFieldMapping = $moduleModel->getColumnFieldMapping();
                    $queryFields_show = array();
                    $sql_fields_show = "SELECT\n                        *\n                    FROM\n                        `global_search_fields`\n                    WHERE\n                        module = '" . $search_module . "'\n                    AND fieldname_show <> ''\n                    AND fieldname_show IS NOT NULL\n                    ORDER BY\n                        id;";
                    $re_fields_show = $adb->pquery($sql_fields_show, array());
                    if (0 < $adb->num_rows($re_fields_show)) {
                        while ($row_fields_show = $adb->fetchByAssoc($re_fields_show)) {
                            $fieldDetails = explode(":", $row_fields_show["fieldname_show"]);
                            $queryFields_show[] = $fieldDetails[2];
                        }
                    }
                    if (!empty($queryFields_show)) {
                        $queryFields_show[] = "id";
                        $queryGenerator->setFields($queryFields_show);
                    } else {
                        $queryFields_show[] = "id";
                        $sql_default_view = "SELECT DISTINCT\n                            vtiger_cvcolumnlist.columnname AS fieldname\n                        FROM\n                            `vtiger_cvcolumnlist`\n                        INNER JOIN (\n                            SELECT\n                                *\n                            FROM\n                                vtiger_customview\n                            WHERE\n                                viewname = 'All' AND vtiger_customview.entitytype = '" . $search_module . "'\n                            ORDER BY\n                                cvid ASC\n                            LIMIT 1\n                        ) vtiger_customview ON vtiger_customview.cvid = vtiger_cvcolumnlist.cvid\n                        ORDER BY\n                            columnindex";
                        $rsFields = $adb->pquery($sql_default_view, array());
                        $numRows = $adb->num_rows($rsFields);
                        if (0 < $numRows) {
                            while ($row = $adb->fetch_array($rsFields)) {
                                $fieldDetails = $row["fieldname"];
                                $fieldDetails = explode(":", $fieldDetails);
                                $queryFields_show[] = $fieldDetails[2];
                            }
                        }
                        $queryGenerator->setFields($queryFields_show);
                    }
                    $listViewContoller = new ListViewController($adb, $user, $queryGenerator);
                    $headerFieldModels = array();
                    $headerFields = $listViewContoller->getListViewHeaderFields();
                    foreach ($headerFields as $fieldName => $webserviceField) {
                        if (in_array($fieldName, array_keys($moduleFieldList))) {
                            if ($webserviceField && !in_array($webserviceField->getPresence(), array(0, 2))) {
                                continue;
                            }
                            $headerFieldModels[$fieldName] = Vtiger_Field_Model::getInstance($fieldName, $moduleModel);
                        }
                    }
                    $search_results[$search_module]["listViewHeaders"] = $headerFieldModels;
                    if ($search_module == "Calendar") {
                        $queryGenerator->addCondition("activitytype", "Emails", "n", "AND");
                    }
                    if ($orderBy) {
                        $fieldModels = $queryGenerator->getModuleFields();
                        $orderByFieldModel = $fieldModels[$orderBy];
                        if ($orderByFieldModel && ($orderByFieldModel->getFieldDataType() == Vtiger_Field_Model::REFERENCE_TYPE || $orderByFieldModel->getFieldDataType() == Vtiger_Field_Model::OWNER_TYPE)) {
                            $queryGenerator->addWhereField($orderBy);
                        }
                    }
                    $query = $queryGenerator->getQuery();
                    $query = str_replace("(.createdtime", "(createdtime", $query);
                    $query = str_replace("(.modifiedtime", "(modifiedtime", $query);
                    if (empty($search_type) && ($search_module == "Contacts" || $search_module == "Leads")) {
                        $query .= " OR (vtiger_crmentity.deleted = 0 AND vtiger_crmentity.label LIKE '%" . $search_value . "%')";
                    }
                    if (0 < count($phoneFields)) {
                        $position = stripos($query, " from ");
                        if ($position) {
                            $split = preg_split("/\\sfrom\\s/i", $query);
                            $whereQ = $split[1];
                            foreach ($phoneFields as $pfield) {
                                $whereQ = str_replace($pfield, "replace(replace(replace(replace(replace(replace(replace(" . $pfield . ", '+', ''), '-', ''), ')', ''),'(',''), '#', ''),'/',''),' ', '')", $whereQ);
                            }
                            $query = $split[0] . " FROM " . $whereQ;
                        }
                    }
                    $searchKey = trim($request->get("value"));
                    if (!empty($searchKey)) {
                        $position = stripos($query, " from ");
                        if ($position) {
                            $split = preg_split("/\\swhere\\s/i", $query);
                            if ($search_module == "ModComments") {
                                $whereQ = "(" . $split[1] . " AND vtiger_modcomments.related_to > 0 AND vtiger_modcomments.related_to IS NOT NULL AND (SELECT crmid from vtiger_crmentity where crmid=vtiger_modcomments.related_to AND vtiger_crmentity.deleted = 0) IS NOT NULL)";
                            } else {
                                $whereQ = "(" . $split[1] . ")";
                            }
                            $convertedLead = "";
                            if ($search_module == "Leads") {
                                $convertedLead = " AND vtiger_leaddetails.converted = 0 ";
                            }
                            $whereQ .= " ";
                            $query = $split[0] . " where " . $whereQ . $convertedLead;
                        }
                    }
                    $startIndex = $pagingModel->getStartIndex();
                    $pageLimit = $pagingModel->getPageLimit();
                    $modules_sortby_label = array("Contacts", "Leads", "Accounts", "Vendors", "Products", "Services");
                    if ($orderBy && $sortOrder) {
                        $viewer->assign("ORDER_BY", $orderBy);
                        $viewer->assign("SORT_ORDER", $sortOrder);
                        if ($sortOrder == "ASC") {
                            $nextSortOrder = "DESC";
                            $sortImage = "icon-chevron-down";
                        } else {
                            $nextSortOrder = "ASC";
                            $sortImage = "icon-chevron-up";
                        }
                        $viewer->assign("NEXT_SORT_ORDER", $nextSortOrder);
                        $viewer->assign("FASORT_IMAGE", $sortImage);
                        $query .= " ORDER BY " . $queryGenerator->getOrderByColumn($orderBy) . " " . $sortOrder;
                    } else {
                        if (in_array($search_module, $modules_sortby_label)) {
                            $query .= " ORDER BY (vtiger_crmentity.label) ASC";
                        } else {
                            $query .= " ORDER BY vtiger_crmentity.modifiedtime DESC";
                        }
                    }
                    $keyword = $request->get("keyword");
                    if (!empty($keyword)) {
                        $keyword = explode(",", $keyword);
                        foreach ($keyword as $k => $item) {
                            $item = trim($item);
                            $item = preg_replace("/[^A-Za-z0-9]/", "", trim($item));
                            $keyword[$k] = $item;
                        }
                        $where = array();
                        $query_1 = explode("FROM", $query);
                        $query_1 = $query_1[0];
                        $query_1 = str_replace("SELECT", "", $query_1);
                        $query_1 = trim($query_1);
                        $query_1 = explode(",", $query_1);
                        $join = array();
                        $moduleModel = Vtiger_Module_Model::getInstance($search_module);
                        $module = Vtiger_Module::getInstance($search_module);
                        $table_index = $module->basetableid;
                        foreach ($query_1 as $field) {
                            $field = explode(".", $field);
                            $field = $field[1];
                            $field_with_as = explode("AS", $field);
                            if (1 < count($field_with_as)) {
                                $field = trim($field_with_as[1]);
                            }
                            if ($field != $table_index) {
                                $field_model = Vtiger_Field_Model::getInstance($field, $moduleModel);
                                if ($field_model) {
                                    if ($field_model->get("uitype") == 10 || $field_model->get("uitype") == 59 || $field_model->get("uitype") == 51) {
                                        $join[] = " LEFT JOIN vtiger_crmentity as vtiger_crmentity" . $field . " ON vtiger_crmentity" . $field . ".crmid = result." . $field . " ";
                                        $condition = array();
                                        foreach ($keyword as $item) {
                                            $condition[] = "vtiger_crmentity" . $field . ".label LIKE '%" . $item . "%' ";
                                        }
                                        $condition = implode(" OR ", $condition);
                                        $where[] = "(" . $condition . ")";
                                    } else {
                                        $condition = array();
                                        foreach ($keyword as $item) {
                                            $condition[] = "result." . $field . " LIKE '%" . $item . "%' ";
                                        }
                                        $condition = implode(" OR ", $condition);
                                        $where[] = "(" . $condition . ")";
                                    }
                                } else {
                                    $condition = array();
                                    foreach ($keyword as $item) {
                                        $condition[] = "result." . $field . " LIKE '%" . $item . "%' ";
                                    }
                                    $condition = implode(" OR ", $condition);
                                    $where[] = "(" . $condition . ")";
                                }
                            }
                        }
                        $query = "SELECT DISTINCT result.* FROM (" . $query . ") result";
                        if (!empty($join)) {
                            $join = implode(" ", $join);
                            $query .= $join;
                        }
                        $query .= " LEFT JOIN vtiger_modcomments ON vtiger_modcomments.related_to = result." . $table_index . " ";
                        if (!empty($where)) {
                            $where = implode(" OR ", $where);
                            $query .= " WHERE " . $where;
                        }
                        foreach ($keyword as $item) {
                            $query .= " OR vtiger_modcomments.commentcontent LIKE '%" . $item . "%' ";
                        }
                        if ($orderBy && $sortOrder) {
                            $orderByColumn = explode(".", $queryGenerator->getOrderByColumn($orderBy));
                            $orderByColumn = "result." . $orderByColumn[1];
                            $query .= " ORDER BY " . $orderByColumn . " " . $sortOrder . " ";
                        }
                        $query_keyword_comment = $query;
                        $re_keyword_comment = $adb->pquery($query_keyword_comment, array());
                        if (0 < $adb->num_rows($re_keyword_comment)) {
                            while ($row_keyword_comment = $adb->fetchByAssoc($re_keyword_comment)) {
                                $record_id = $row_keyword_comment[$table_index];
                                $sql_comment = "SELECT\n                                    *\n                                FROM\n                                    `vtiger_modcomments`\n                                INNER JOIN vtiger_crmentity ON vtiger_crmentity.crmid = vtiger_modcomments.modcommentsid\n                                WHERE\n                                    vtiger_modcomments.related_to = " . $record_id . "\n                                AND vtiger_crmentity.deleted = 0 AND ";
                                $condition = array();
                                foreach ($keyword as $item) {
                                    $condition[] = " vtiger_modcomments.commentcontent LIKE '%" . $item . "%' ";
                                }
                                $condition = implode(" OR ", $condition);
                                $sql_comment .= " (" . $condition . ") ";
                                $re_comment = $adb->pquery($sql_comment, array());
                                if (0 < $adb->num_rows($re_comment)) {
                                    $comments = array();
                                    while ($row_comment = $adb->fetchByAssoc($re_comment)) {
                                        $comments[] = $row_comment;
                                    }
                                    $record_comments[$record_id] = $comments;
                                }
                            }
                        }
                    }
                    $countQuery = "";
                    $position = stripos($query, " from ");
                    if ($position) {
                        $split = preg_split("/\\sfrom\\s/i", $query);
                        $splitCount = count($split);
                        if (!empty($keyword)) {
                            $countQuery = "SELECT count(DISTINCT result." . $table_index . ") AS count ";
                        } else {
                            $countQuery = "SELECT count(*) AS count ";
                        }
                        for ($i = 1; $i < $splitCount; $i++) {
                            $countQuery = $countQuery . " FROM " . $split[$i];
                        }
                    }
                    if ($debug == "1") {
                        echo "countQuery : " . $countQuery . " <br><br>";
                    }
                    $_SESSION["GlobalSearch_" . $search_module . "_countResult"] = $countQuery;
                    $countResult = $adb->pquery($countQuery, array());
                    $totalResults = $adb->query_result($countResult, 0, "count");
                    $search_results[$search_module]["totalResults"] = $totalResults;
                    $pageCount = ceil((int) $totalResults / (int) $pageLimit);
                    if ($pageCount == 0) {
                        $pageCount = 1;
                    }
                    $search_results[$search_module]["PAGE_COUNT"] = $pageCount;
                    $query .= " LIMIT " . $startIndex . "," . ($pageLimit + 1);
                    if ($debug == "1") {
                        echo "query : " . $query . " <br><br>";
                    }
                    $result = $adb->pquery($query, array());
                    $listViewEntries = $listViewContoller->getListViewRecords($moduleFocus, $search_module, $result);
                    $pagingModel->calculatePageRange($listViewEntries);
                    if ($pageLimit < $adb->num_rows($result)) {
                        array_pop($listViewEntries);
                        $pagingModel->set("nextPageExists", true);
                    } else {
                        $pagingModel->set("nextPageExists", false);
                    }
                    $index = 0;
                    $listViewRecordModels = array();
                    foreach ($listViewEntries as $recordId => $record) {
                        $rawData = $adb->query_result_rowdata($result, $index++);
                        if ($search_module == "Emails") {
                            if ($rawData["idlists"] != "") {
                                $parentIdStrings = "";
                                $arrParentIdLists = explode("|", $rawData["idlists"]);
                                foreach ($arrParentIdLists as $parentId) {
                                    if ($parentId != "") {
                                        list($pId, $mId) = explode("@", $parentId);
                                        if ($mId == "1") {
                                            $pRecordModels = Vtiger_Record_Model::getInstanceById($pId);
                                            $parentIdStrings .= "<a href=\"" . $pRecordModels->getDetailViewUrl() . "\">" . $pRecordModels->getDisplayName() . "</a>, ";
                                        } else {
                                            $pRecordModels = Vtiger_Record_Model::getInstanceById($pId, "Users");
                                            $parentIdStrings .= "<a href=\"" . $pRecordModels->getDetailViewUrl() . "\">" . $pRecordModels->getDisplayName() . "</a>, ";
                                        }
                                    }
                                }
                                $parentIdStrings = trim($parentIdStrings, ", ");
                                $record["parent_id"] = $parentIdStrings;
                            }
                            if ($rawData["description"] != "") {
                                $emailRecordModel = Vtiger_Record_Model::getInstanceById($recordId);
                                $record["description"] = $emailRecordModel->get("description");
                            }
                        }
                        $record["id"] = $recordId;
                        $listViewRecordModels[$recordId] = $moduleModel->getRecordFromArray($record, $rawData);
                    }
                    $search_results[$search_module]["listViewEntries"] = $listViewRecordModels;
                    $pagingModels[$search_module] = $pagingModel;
                }
            }
            $viewer->assign("SEARCH_RESULTS", $search_results);
            $viewer->assign("PAGING_MODELS", $pagingModels);
            if (!empty($record_comments)) {
                $viewer->assign("RECORD_COMMENTS", $record_comments);
            }
        } else {
            $viewer->assign("NO_MODULE", "true");
        }
        if ($search_module != "" && $search_module != "undefined" && $request->get("ajax") == 1) {
            $viewer->assign("LISTVIEW_HEADERS", $headerFieldModels);
            $viewer->assign("LISTVIEW_ENTRIES", $listViewRecordModels);
            $viewer->assign("PAGING_MODEL", $pagingModel);
            $viewer->assign("LISTVIEW_ENTRIES_COUNT", count($listViewRecordModels));
            $viewer->assign("SEARCH_MODULE", $search_module);
            $viewer->assign("PAGE_NUMBER", $request->get("page"));
            $viewer->assign("SEARCH_MODE_RESULTS", true);
        }
        $viewer->assign("PAGING_MODEL", $pagingModel);
        $viewer->assign("VALUE", trim($request->get("value")));
        $viewer->assign("KEY_WORD_SEARCH", trim($request->get("keyword")));
    }
    public function getHeaderScripts(Vtiger_Request $request)
    {
        $headerScriptInstances = parent::getHeaderScripts($request);
        $moduleName = $request->getModule();
        $jsFileNames = array("modules.GlobalSearch.resources.List");
        $jsScriptInstances = $this->checkAndConvertJsScripts($jsFileNames);
        $headerScriptInstances = array_merge($headerScriptInstances, $jsScriptInstances);
        return $headerScriptInstances;
    }
    public function getPresenceFields($module)
    {
        global $adb;
        $arrFields = array();
        $tabid = getTabid($module);
        $sql = "SELECT fieldname FROM `vtiger_field` WHERE tabid=? AND presence IN (0,2)";
        $rs = $adb->pquery($sql, array($tabid));
        if (0 < $adb->num_rows($rs)) {
            while ($row = $adb->fetch_array($rs)) {
                $arrFields[] = $row["fieldname"];
            }
        }
        return $arrFields;
    }
    public function getPhoneFields($module)
    {
        global $adb;
        $arrFields = array();
        $tabid = getTabid($module);
        $sql = "SELECT fieldname,tablename FROM `vtiger_field` WHERE uitype=? AND tabid=?";
        $rs = $adb->pquery($sql, array("11", $tabid));
        if (0 < $adb->num_rows($rs)) {
            while ($row = $adb->fetch_array($rs)) {
                $arrFields[$row["fieldname"]] = $row["tablename"];
            }
        }
        return $arrFields;
    }
}

?>