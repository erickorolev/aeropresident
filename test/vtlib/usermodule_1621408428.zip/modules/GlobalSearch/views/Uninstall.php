<?php

include_once "vtlib/Vtiger/Module.php";
class GlobalSearch_Uninstall_View extends Settings_Vtiger_Index_View
{
    public function process(Vtiger_Request $request)
    {
        global $adb;
        echo "<div class=\"container-fluid\">\r\n                <div class=\"widget_header row-fluid\">\r\n                    <h3>Global Search</h3>\r\n                </div>\r\n                <hr>";
        $module = Vtiger_Module::getInstance("GlobalSearch");
        if ($module) {
            $module->delete();
        }
        $msg = $this->removeData();
        echo $msg;
        $res_template = $this->delete_folder("layouts/vlayout/modules/GlobalSearch");
        echo "&nbsp;&nbsp;- Delete Global Search template folder";
        if ($res_template) {
            echo " - DONE";
        } else {
            echo " - <b>ERROR</b>";
        }
        echo "<br>";
        $res_templatev7 = $this->delete_folder("layouts/v7/modules/GlobalSearch");
        echo "&nbsp;&nbsp;- Delete Global Search template folder";
        if ($res_templatev7) {
            echo " - DONE";
        } else {
            echo " - <b>ERROR</b>";
        }
        echo "<br>";
        $res_module = $this->delete_folder("modules/GlobalSearch");
        echo "&nbsp;&nbsp;- Delete Global Search module folder";
        if ($res_module) {
            echo " - DONE";
        } else {
            echo " - <b>ERROR</b>";
        }
        echo "<br>Module was Uninstalled.</div>";
    }
    public function delete_folder($tmp_path)
    {
        if (!is_writeable($tmp_path) && is_dir($tmp_path)) {
            chmod($tmp_path, 511);
        }
        $handle = opendir($tmp_path);
        while ($tmp = readdir($handle)) {
            if ($tmp != ".." && $tmp != "." && $tmp != "") {
                if (is_writeable($tmp_path . DS . $tmp) && is_file($tmp_path . DS . $tmp)) {
                    unlink($tmp_path . DS . $tmp);
                } else {
                    if (!is_writeable($tmp_path . DS . $tmp) && is_file($tmp_path . DS . $tmp)) {
                        chmod($tmp_path . DS . $tmp, 438);
                        unlink($tmp_path . DS . $tmp);
                    }
                }
                if (is_writeable($tmp_path . DS . $tmp) && is_dir($tmp_path . DS . $tmp)) {
                    $this->delete_folder($tmp_path . DS . $tmp);
                } else {
                    if (!is_writeable($tmp_path . DS . $tmp) && is_dir($tmp_path . DS . $tmp)) {
                        chmod($tmp_path . DS . $tmp, 511);
                        $this->delete_folder($tmp_path . DS . $tmp);
                    }
                }
            }
        }
        closedir($handle);
        rmdir($tmp_path);
        if (!is_dir($tmp_path)) {
            return true;
        }
        return false;
    }
    public function removeData()
    {
        global $adb;
        $msg = "";
        $adb->pquery("DELETE FROM vtiger_settings_field WHERE `name` = ?", array("Global Search"));
        $sql = "DROP TABLE `global_search_modules`, `global_search_fields`,`global_search_quick_search_settings`,`global_search_method`,`global_search_log`;";
        $result = $adb->pquery($sql, array());
        $msg .= "&nbsp;&nbsp;- Delete Global Search tables";
        if ($result) {
            $msg .= " - DONE";
        } else {
            $msg .= " - <b>ERROR</b>";
        }
        $msg .= "<br>";
        return $msg;
    }
}

?>