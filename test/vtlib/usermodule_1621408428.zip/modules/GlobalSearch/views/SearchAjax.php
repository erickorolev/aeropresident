<?php

class GlobalSearch_SearchAjax_View extends Vtiger_Index_View
{
    public function checkPermission(Vtiger_Request $request)
    {
        return true;
    }
    public function process(Vtiger_Request $request)
    {
        global $adb;
        global $vtiger_current_version;
        $viewer = $this->getViewer($request);
        $moduleName = $request->getModule();
        $search_module = $request->get("search_module");
        $searchVals = explode(" ", $request->get("value"));
        $pagingModel = new Vtiger_Paging_Model();
        $current_page = $request->get("page") ? $request->get("page") : 0;
        $pagingModel->set("page", $current_page);
        $queryFields = array();
        $orderBy = $request->get("orderby");
        $sortOrder = $request->get("sortorder");
        $user = Users_Record_Model::getCurrentUserModel();
        $moduleFocus = CRMEntity::getInstance($search_module);
        $moduleModel = Vtiger_Module_Model::getInstance($search_module);
        if (version_compare($vtiger_current_version, "7.0.0", "<")) {
            $queryGenerator = new QueryGenerator($search_module, $user);
        } else {
            $queryGenerator = new EnhancedQueryGenerator($search_module, $user);
        }
        $referenceFieldInfoList = $queryGenerator->getReferenceFieldInfoList();
        $referenceFieldList = $queryGenerator->getReferenceFieldList();
        $modulePhoneFields = $this->getPhoneFields($search_module);
        $moduleFieldList = $moduleModel->getFields();
        $queryFields[] = "id";
        $queryFieldsShow[] = "id";
        $rowFieldsArray[] = "id";
        $rsFields = $adb->pquery("SELECT * FROM `global_search_fields` WHERE module=? ORDER BY id", array($search_module));
        $numRows = $adb->num_rows($rsFields);
        if ($numRows == 0) {
            $rsFields = $adb->pquery("SELECT vtiger_cvcolumnlist.columnname AS fieldname\r\n                                FROM `vtiger_cvcolumnlist`\r\n                                INNER JOIN vtiger_customview ON vtiger_customview.cvid=vtiger_cvcolumnlist.cvid\r\n                                WHERE entitytype=? AND viewname='All' ORDER BY columnindex", array($search_module));
            $numRows = $adb->num_rows($rsFields);
        }
        if (0 < $numRows) {
            while ($rowFields = $adb->fetch_array($rsFields)) {
                $rowFieldsArray[] = $rowFields;
                $fieldShow = explode(":", $rowFields["fieldname_show"]);
                $fieldDetails = explode(":", $rowFields["fieldname"]);
                if (0 < count($fieldDetails) && !empty($fieldDetails[2])) {
                    $queryFields[] = $fieldDetails[2];
                }
                if (0 < count($fieldShow) && !empty($fieldShow[2])) {
                    $queryFieldsShow[] = $fieldShow[2];
                }
            }
            if (count($queryFields) == 1) {
                $rsFields = $adb->pquery("SELECT vtiger_cvcolumnlist.columnname AS fieldname\r\n                                FROM `vtiger_cvcolumnlist`\r\n                                INNER JOIN vtiger_customview ON vtiger_customview.cvid=vtiger_cvcolumnlist.cvid\r\n                                WHERE entitytype=? AND viewname='All' ORDER BY columnindex", array($search_module));
                $numRows = $adb->num_rows($rsFields);
            }
            if (count($queryFieldsShow) == 1) {
                $rsFieldsShow = $adb->pquery("SELECT vtiger_cvcolumnlist.columnname AS fieldname\r\n                                FROM `vtiger_cvcolumnlist`\r\n                                INNER JOIN vtiger_customview ON vtiger_customview.cvid=vtiger_cvcolumnlist.cvid\r\n                                WHERE entitytype=? AND viewname='All' ORDER BY columnindex", array($search_module));
                while ($rowFieldsShow = $adb->fetch_array($rsFieldsShow)) {
                    $fieldShow = explode(":", $rowFieldsShow["fieldname"]);
                    if (0 < count($fieldShow)) {
                        $queryFieldsShow[] = $fieldShow[2];
                    }
                }
            }
        }
        $presenceFields = $this->getPresenceFields($search_module);
        $i = 0;
        if (0 < $numRows) {
            $queryGenerator->startGroup("");
            foreach ($rowFieldsArray as $rowField) {
                $fieldDetails = explode(":", $rowField["fieldname"]);
                if (in_array($fieldDetails[2], $presenceFields)) {
                    if (in_array($fieldDetails[2], $referenceFieldList) && count($referenceFieldInfoList[$fieldDetails[2]]) == 0) {
                        continue;
                    }
                    if (empty($fieldDetails[2]) && $fieldDetails[1] == "crmid" && $fieldDetails[0] == "vtiger_crmentity") {
                        $name = $queryGenerator->getSQLColumn("id");
                    } else {
                        $name = $fieldDetails[2];
                    }
                    $fieldModel = $moduleFieldList[$name];
                    if (empty($fieldModel) || !$fieldModel->isViewableInDetailView()) {
                        continue;
                    }
                    if (in_array($name, array_keys($modulePhoneFields))) {
                        $searchKey = preg_replace("/[^A-Za-z0-9]/", "", trim($request->get("value")));
                        if ($searchKey != "") {
                            $phoneFields[] = $modulePhoneFields[$name] . "." . $name;
                            if (0 < $i) {
                                $queryGenerator->addConditionGlue("or");
                            }
                            $queryGenerator->addCondition($name, $searchKey, "c");
                            $i++;
                        }
                    } else {
                        $searchKey = trim($request->get("value"));
                        if ($fieldDetails[4] == "D" || $fieldDetails[4] == "DT" || $fieldDetails[4] == "T") {
                            $searchValue = DateTimeField::convertToDBFormat($searchKey);
                            if (0 < $i) {
                                $queryGenerator->addConditionGlue("or");
                            }
                            $queryGenerator->addCondition($name, $searchValue, "e");
                            $i++;
                        } else {
                            if (($fieldDetails[4] == "N" || $fieldDetails[4] == "NN" || $fieldDetails[4] == "I") && is_numeric($searchKey)) {
                                if (0 < $i) {
                                    $queryGenerator->addConditionGlue("or");
                                }
                                $queryGenerator->addCondition($name, $searchKey, "e");
                                $i++;
                            } else {
                                if ($fieldDetails[4] != "N" && $fieldDetails[4] != "NN" && $fieldDetails[4] != "I") {
                                    if (0 < $i) {
                                        $queryGenerator->addConditionGlue("or");
                                    }
                                    $queryGenerator->addCondition($name, $searchKey, "c");
                                    $i++;
                                }
                            }
                        }
                    }
                }
            }
            $queryGenerator->endGroup();
        }
        $search_type = $request->get("search_type");
        if (!empty($search_type) && $search_type == "vt_standard") {
            $search_params = $request->get("search_params");
            if (!empty($search_params)) {
                if (empty($search_params[1])) {
                    unset($search_params[1]);
                }
                $advFilterList = Vtiger_Util_Helper::transferListSearchParamsToFilterCondition($search_params, $moduleModel);
                if (is_array($advFilterList) && 0 < count($advFilterList)) {
                    $queryGenerator->addConditionGlue("and");
                    vimport("~~/modules/CustomView/CustomView.php");
                    $customView = new CustomView($search_module);
                    $dateSpecificConditions = $customView->getStdFilterConditions();
                    foreach ($advFilterList as $groupindex => $groupcolumns) {
                        $filtercolumns = $groupcolumns["columns"];
                        if (0 < count($filtercolumns)) {
                            $queryGenerator->startGroup("");
                            foreach ($filtercolumns as $index => $filter) {
                                $specialDateTimeConditions = Vtiger_Functions::getSpecialDateTimeCondtions();
                                $nameComponents = explode(":", $filter["columnname"]);
                                if (empty($nameComponents[2]) && $nameComponents[1] == "crmid" && $nameComponents[0] == "vtiger_crmentity") {
                                    $name = $queryGenerator->getSQLColumn("id");
                                } else {
                                    $name = $nameComponents[2];
                                }
                                if (($nameComponents[4] == "D" || $nameComponents[4] == "DT") && in_array($filter["comparator"], $dateSpecificConditions)) {
                                    $filter["stdfilter"] = $filter["comparator"];
                                    $valueComponents = explode(",", $filter["value"]);
                                    if ($filter["comparator"] == "custom") {
                                        $filter["startdate"] = DateTimeField::convertToDBFormat($valueComponents[0]);
                                        $filter["enddate"] = DateTimeField::convertToDBFormat($valueComponents[1]);
                                    }
                                    $dateFilterResolvedList = $customView->resolveDateFilterValue($filter);
                                    $value[] = $queryGenerator->fixDateTimeValue($name, $dateFilterResolvedList["startdate"]);
                                    $value[] = $queryGenerator->fixDateTimeValue($name, $dateFilterResolvedList["enddate"], false);
                                    $queryGenerator->addCondition($name, $value, "BETWEEN");
                                } else {
                                    if (($nameComponents[4] == "D" || $nameComponents[4] == "DT") && in_array($filter["comparator"], $specialDateTimeConditions)) {
                                        $values = EnhancedQueryGenerator::getSpecialDateConditionValue($filter["comparator"], $filter["value"], $nameComponents[4], true);
                                        $queryGenerator->addCondition($name, $values["date"], $values["comparator"]);
                                    } else {
                                        $queryGenerator->addCondition($name, $filter["value"], $filter["comparator"]);
                                    }
                                }
                                $columncondition = $filter["column_condition"];
                                if (!empty($columncondition)) {
                                    $queryGenerator->addConditionGlue($columncondition);
                                }
                            }
                            $queryGenerator->endGroup();
                            $groupConditionGlue = $groupcolumns["condition"];
                            if (!empty($groupConditionGlue)) {
                                $queryGenerator->addConditionGlue($groupConditionGlue);
                            }
                        }
                    }
                }
            }
        }
        $queryGenerator->setFields($queryFieldsShow);
        $listViewContoller = new ListViewController($adb, $user, $queryGenerator);
        $headerFieldModels = array();
        $headerFields = $listViewContoller->getListViewHeaderFields();
        foreach ($headerFields as $fieldName => $webserviceField) {
            if (in_array($fieldName, array_keys($moduleFieldList))) {
                if ($webserviceField && !in_array($webserviceField->getPresence(), array(0, 2))) {
                    continue;
                }
                $headerFieldModels[$fieldName] = Vtiger_Field_Model::getInstance($fieldName, $moduleModel);
            }
        }
        if ($search_module == "Calendar") {
            $queryGenerator->addCondition("activitytype", "Emails", "n", "AND");
        }
        if ($orderBy) {
            $fieldModels = $queryGenerator->getModuleFields();
            $orderByFieldModel1 = $fieldModels[$orderBy];
            if ($orderByFieldModel1 && ($orderByFieldModel1->getFieldDataType() == Vtiger_Field_Model::REFERENCE_TYPE || $orderByFieldModel1->getFieldDataType() == Vtiger_Field_Model::OWNER_TYPE)) {
                $queryGenerator->addWhereField($orderBy);
            }
        }
        $query = $queryGenerator->getQuery();
        if (0 < count($phoneFields)) {
            $position = stripos($query, " from ");
            if ($position) {
                $split = preg_split("/\\sfrom\\s/i", $query);
                $whereQ = $split[1];
                foreach ($phoneFields as $pfield) {
                    $whereQ = str_replace($pfield, "replace(replace(replace(replace(replace(replace(replace(" . $pfield . ", '+', ''), '-', ''), ')', ''),'(',''), '#', ''),'/',''),' ', '')", $whereQ);
                }
                $query = $split[0] . " FROM " . $whereQ;
            }
        }
        $position = stripos($query, " from ");
        if ($position) {
            $split = preg_split("/\\swhere\\s/i", $query);
            $whereQ = "(" . $split[1] . ")";
            $convertedLead = "";
            if ($search_module == "Leads") {
                $convertedLead = " AND vtiger_leaddetails.converted = 0 ";
            }
            $whereQ .= " OR (vtiger_crmentity.deleted = 0 " . $convertedLead . " AND ( vtiger_crmentity.label LIKE '%" . $adb->sql_escape_string(trim($request->get("value"))) . "%' ) AND vtiger_crmentity.crmid > 0)";
            $query = $split[0] . " where " . $whereQ;
        }
        $startIndex = $pagingModel->getStartIndex();
        $pageLimit = $pagingModel->getPageLimit();
        $modules_sortby_label = array("Contacts", "Leads", "Accounts", "Vendors", "Products", "Services");
        if ($orderBy && $sortOrder) {
            $viewer->assign("ORDER_BY", $orderBy);
            $viewer->assign("SORT_ORDER", $sortOrder);
            if ($sortOrder == "ASC") {
                $nextSortOrder = "DESC";
                $sortImage = "icon-chevron-down";
            } else {
                $nextSortOrder = "ASC";
                $sortImage = "icon-chevron-up";
            }
            $viewer->assign("NEXT_SORT_ORDER", $nextSortOrder);
            $viewer->assign("FASORT_IMAGE", $sortImage);
            $query .= "ORDER BY " . $queryGenerator->getOrderByColumn($orderBy) . " " . $sortOrder;
        } else {
            if (in_array($search_module, $modules_sortby_label)) {
                $query .= " ORDER BY (vtiger_crmentity.label) ASC";
            } else {
                $query .= " ORDER BY vtiger_crmentity.modifiedtime DESC";
            }
        }
        $query .= " LIMIT " . $startIndex . "," . ($pageLimit + 1);
        $result = $adb->pquery($query, array());
        $listViewEntries = $listViewContoller->getListViewRecords($moduleFocus, $search_module, $result);
        $pagingModel->calculatePageRange($listViewEntries);
        if ($pageLimit < $adb->num_rows($result)) {
            array_pop($listViewEntries);
            $pagingModel->set("nextPageExists", true);
        } else {
            $pagingModel->set("nextPageExists", false);
        }
        $index = 0;
        $listViewRecordModels = array();
        foreach ($listViewEntries as $recordId => $record) {
            $rawData = $adb->query_result_rowdata($result, $index++);
            if ($search_module == "Emails") {
                if ($rawData["idlists"] != "") {
                    $parentIdStrings = "";
                    $arrParentIdLists = explode("|", $rawData["idlists"]);
                    foreach ($arrParentIdLists as $parentId) {
                        if ($parentId != "") {
                            list($pId, $mId) = explode("@", $parentId);
                            if ($mId == "1") {
                                $pRecordModels = Vtiger_Record_Model::getInstanceById($pId);
                                $parentIdStrings .= "<a href=\"" . $pRecordModels->getDetailViewUrl() . "\">" . $pRecordModels->getDisplayName() . "</a>, ";
                            } else {
                                $pRecordModels = Vtiger_Record_Model::getInstanceById($pId, "Users");
                                $parentIdStrings .= "<a href=\"" . $pRecordModels->getDetailViewUrl() . "\">" . $pRecordModels->getDisplayName() . "</a>, ";
                            }
                        }
                    }
                    $parentIdStrings = trim($parentIdStrings, ", ");
                    $record["parent_id"] = $parentIdStrings;
                }
                if ($rawData["description"] != "") {
                    $emailRecordModel = Vtiger_Record_Model::getInstanceById($recordId);
                    $record["description"] = $emailRecordModel->get("description");
                }
            }
            $record["id"] = $recordId;
            $listViewRecordModels[$recordId] = $moduleModel->getRecordFromArray($record, $rawData);
        }
        $viewer->assign("LISTVIEW_HEADERS", $headerFieldModels);
        $viewer->assign("LISTVIEW_ENTRIES", $listViewRecordModels);
        $viewer->assign("PAGING_MODEL", $pagingModel);
        $viewer->assign("LISTVIEW_ENTRIES_COUNT", count($listViewRecordModels));
        $viewer->assign("SEARCH_MODULE", $search_module);
        $viewer->assign("PAGE_NUMBER", $request->get("page"));
        $viewer->assign("VALUE", trim($request->get("value")));
        $viewer->assign("SEARCH_MODE_RESULTS", true);
        $viewer->assign("CURRENT_USER_MODEL", Users_Record_Model::getCurrentUserModel());
        $viewer->view("ListViewContents.tpl", $moduleName);
    }
    public function getPresenceFields($module)
    {
        global $adb;
        $arrFields = array();
        $tabid = getTabid($module);
        $sql = "SELECT fieldname FROM `vtiger_field` WHERE tabid=? AND presence IN (0,2)";
        $rs = $adb->pquery($sql, array($tabid));
        if (0 < $adb->num_rows($rs)) {
            while ($row = $adb->fetch_array($rs)) {
                $arrFields[] = $row["fieldname"];
            }
        }
        return $arrFields;
    }
    public function getPhoneFields($module)
    {
        global $adb;
        $arrFields = array();
        $tabid = getTabid($module);
        $sql = "SELECT fieldname,tablename FROM `vtiger_field` WHERE uitype=? AND tabid=?";
        $rs = $adb->pquery($sql, array("11", $tabid));
        if (0 < $adb->num_rows($rs)) {
            while ($row = $adb->fetch_array($rs)) {
                $arrFields[$row["fieldname"]] = $row["tablename"];
            }
        }
        return $arrFields;
    }
}

?>