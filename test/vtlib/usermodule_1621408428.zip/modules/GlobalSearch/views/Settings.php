<?php

class GlobalSearch_Settings_View extends Settings_Vtiger_Index_View
{
    public function __construct()
    {
        parent::__construct();
    }
    public function preProcess(Vtiger_Request $request)
    {
        parent::preProcess($request);
        $adb = PearDatabase::getInstance();
        $module = $request->getModule();
        $viewer = $this->getViewer($request);
        $viewer->assign("QUALIFIED_MODULE", $module);
    }
    public function process(Vtiger_Request $request)
    {
        $module = $request->getModule();
        $adb = PearDatabase::getInstance();
        $mode = $request->getMode();
        if ($mode) {
            $this->{$mode}($request);
        } else {
            $this->renderSettingsUI($request);
        }
    }
    public function step2(Vtiger_Request $request)
    {
        global $site_URL;
        $module = $request->getModule();
        $viewer = $this->getViewer($request);
        $viewer->assign("SITE_URL", $site_URL);
        $viewer->assign("ORDER_URL", "http://www.vtexperts.com/extension/vtiger-global-search/");
        $viewer->view("Step2.tpl", $module);
    }
    public function step3(Vtiger_Request $request)
    {
        $module = $request->getModule();
        $viewer = $this->getViewer($request);
        $viewer->view("Step3.tpl", $module);
    }
    public function renderSettingsUI(Vtiger_Request $request)
    {
        $adb = PearDatabase::getInstance();
        $module = $request->getModule();
        $viewer = $this->getViewer($request);
        $userPrivModel = Users_Privileges_Model::getCurrentUserPrivilegesModel();
        $presence = array(0, 2);
        $moduleModels = Vtiger_Module_Model::getAll($presence);
        $restrictedModules = array("Webmails", "Integration", "Dashboard");
        foreach ($moduleModels as $key => $moduleModel) {
            if (in_array($moduleModel->getName(), $restrictedModules) || $moduleModel->get("isentitytype") != 1) {
                unset($moduleModels[$key]);
            }
        }
        $allModules = array();
        foreach ($moduleModels as $tabid => $moduleModel) {
            $moduleName = $moduleModel->getName();
            if ($moduleName == "Users" || $moduleName == "Events") {
                continue;
            }
            if ($userPrivModel->hasModuleActionPermission($moduleModel->getId(), "DetailView")) {
                $allModules[$moduleName] = $moduleModel;
            }
        }
        $viewer->assign("ALL_MODULE", array_keys($allModules));
        $sql = "SELECT * FROM global_search_method";
        $re = $adb->pquery($sql, array());
        if (0 < $adb->num_rows($re)) {
            $search_method = $adb->query_result($re, 0, "search_method");
            $limit_per_module = $adb->query_result($re, 0, "limit_per_module");
        }
        $viewer->assign("SEARCH_METHOD", $search_method);
        $viewer->assign("LIMIT_PER_MODULE", $limit_per_module);
        $rsSearch = $adb->pquery("SELECT * FROM `global_search_modules` ORDER BY sequence", array());
        $searchModules = array();
        if (0 < $adb->num_rows($rsSearch)) {
            while ($row = $adb->fetch_array($rsSearch)) {
                $searchModules[$row["module"]] = $row["sequence"];
            }
        }
        $viewer->assign("SEARCH_MODULES", $searchModules);
        echo $viewer->view("Settings.tpl", $module, true);
    }
    /**
     * Function to get the list of Script models to be included
     * @param Vtiger_Request $request
     * @return <Array> - List of Vtiger_JsScript_Model instances
     */
    public function getHeaderScripts(Vtiger_Request $request)
    {
        $headerScriptInstances = parent::getHeaderScripts($request);
        $moduleName = $request->getModule();
        $jsFileNames = array("modules.GlobalSearch.resources.Settings");
        $jsScriptInstances = $this->checkAndConvertJsScripts($jsFileNames);
        $headerScriptInstances = array_merge($headerScriptInstances, $jsScriptInstances);
        return $headerScriptInstances;
    }
}

?>