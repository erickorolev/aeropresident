<?php

class GlobalSearch_Module_Model extends Vtiger_Module_Model
{
    public function getSettingLinks()
    {
        $settingsLinks[] = array("linktype" => "MODULESETTING", "linklabel" => "Settings", "linkurl" => "index.php?module=GlobalSearch&parent=Settings&view=Settings", "linkicon" => "");
        return $settingsLinks;
    }
}

?>