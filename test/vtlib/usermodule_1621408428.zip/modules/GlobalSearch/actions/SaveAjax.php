<?php

class GlobalSearch_SaveAjax_Action extends Vtiger_Save_Action
{
    public function process(Vtiger_Request $request)
    {
        global $adb;
        $search_module = $request->get("search_module");
        $active = $request->get("active");
        $fields = $request->get("selectedModuleFields");
        $fields = explode(",", $fields);
        $fields_show = $request->get("fields_show");
        $fields_showSorted = $request->get("selectedColumnsSorted");
        $quick_search_fields_search = $request->get("selectedSearchFields");
        $quick_search_fields_show = $request->get("selectedQuickSearchFields");
        $enable_in_quick_search = $request->get("enable_in_quick_search");
        $fields_showSorted = explode(",", $fields_showSorted);
        $rs = $adb->pquery("SELECT * FROM `global_search_modules` WHERE module=?", array($search_module));
        if (0 < $adb->num_rows($rs)) {
            $adb->pquery("UPDATE `global_search_modules` SET `active`=? WHERE (`module`=?)", array($active, $search_module));
        } else {
            $adb->pquery("INSERT INTO `global_search_modules` (`module`, `active`) VALUES (?, ?)", array($search_module, $active));
        }
        $adb->pquery("DELETE FROM `global_search_fields` WHERE (`module`=?)", array($search_module));
        if (is_array($fields)) {
            foreach ($fields as $field) {
                $adb->pquery("INSERT INTO `global_search_fields` (`module`, `fieldname`) VALUES (?, ?)", array($search_module, $field));
            }
        }
        if (is_array($fields_show)) {
            foreach ($fields_showSorted as $field) {
                $adb->pquery("INSERT INTO `global_search_fields` (`module`, `fieldname_show`) VALUES (?, ?)", array($search_module, $field));
            }
        }
        $sql = "SELECT * FROM `global_search_quick_search_settings` WHERE module = ?;";
        $re = $adb->pquery($sql, array($search_module));
        if (0 < $adb->num_rows($re)) {
            $sql = "UPDATE global_search_quick_search_settings SET search_fields=?,show_fields=?,enabled=? WHERE module=?; ";
            $adb->pquery($sql, array($quick_search_fields_search, $quick_search_fields_show, $enable_in_quick_search, $search_module));
        } else {
            $sql = "INSERT INTO global_search_quick_search_settings(search_fields,show_fields,enabled,module) VALUE(?,?,?,?); ";
            $adb->pquery($sql, array($quick_search_fields_search, $quick_search_fields_show, $enable_in_quick_search, $search_module));
        }
        $response = new Vtiger_Response();
        $response->setEmitType(Vtiger_Response::$EMIT_JSON);
        $response->setResult(array("_module" => $search_module));
        $response->emit();
    }
}

?>