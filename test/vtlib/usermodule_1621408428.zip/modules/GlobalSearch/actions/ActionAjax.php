<?php

class GlobalSearch_ActionAjax_Action extends Vtiger_Save_Action
{
    public function checkPermission(Vtiger_Request $request)
    {
    }
    public function __construct()
    {
        parent::__construct();
        $this->exposeMethod("updateSequenceNumber");
        $this->exposeMethod("searchRecord");
        $this->exposeMethod("recordToLog");
        $this->exposeMethod("ajaxShowLogged");
        $this->exposeMethod("updateSearch_method");
        $this->exposeMethod("getCountRecord");
    }
    public function process(Vtiger_Request $request)
    {
        $mode = $request->get("mode");
        if (!empty($mode)) {
            $this->invokeExposedMethod($mode, $request);
        }
    }
    public function updateSearch_method(Vtiger_Request $request)
    {
        global $adb;
        $search_method = $request->get("search_method");
        $limit_per_module = $request->get("limit_per_module");
        $sql = "SELECT * FROM global_search_method";
        $re = $adb->pquery($sql, array());
        if (0 < $adb->num_rows($re)) {
            $sql = "UPDATE global_search_method SET search_method = '" . $search_method . "', limit_per_module=" . $limit_per_module . ";";
            $adb->pquery($sql, array());
        } else {
            $sql = "INSERT INTO global_search_method(search_method,limit_per_module) VALUE('" . $search_method . "'," . $limit_per_module . ")";
            $adb->pquery($sql, array());
        }
        $response = new Vtiger_Response();
        $response->setResult(array("success" => true));
        $response->emit();
    }
    public function updateSequenceNumber(Vtiger_Request $request)
    {
        $response = new Vtiger_Response();
        try {
            $db = PearDatabase::getInstance();
            $sequenceList = $request->get("sequence");
            $query = "UPDATE global_search_modules SET sequence = CASE module ";
            foreach ($sequenceList as $blockId => $sequence) {
                $query .= " WHEN '" . $blockId . "' THEN " . $sequence;
            }
            $query .= " END ";
            $query .= " WHERE module IN (" . generateQuestionMarks($sequenceList) . ")";
            $db->pquery($query, array_keys($sequenceList));
            $response->setResult(array("success" => true));
        } catch (Exception $e) {
            $response->setError($e->getCode(), $e->getMessage());
        }
        $response->emit();
    }
    public function recordToLog(Vtiger_Request $request)
    {
        global $adb;
        $current_user = Users_Record_Model::getCurrentUserModel();
        $current_user_id = $current_user->getId();
        $response = new Vtiger_Response();
        $record = $request->get("record");
        $record_model = Vtiger_Record_Model::getInstanceById($record);
        $record_module_name = $record_model->getModuleName();
        if ($record_module_name != "ModComments") {
            $query = "DELETE FROM global_search_log WHERE crmid=? AND userid=?";
            $adb->pquery($query, array($record, $current_user_id));
            $query = "INSERT INTO global_search_log (crmid,userid) VALUES(" . $record . "," . $current_user_id . ")";
            $adb->pquery($query, array());
        }
        $response->setResult(array("success" => true));
        $response->emit();
    }
    public function ajaxShowLogged(Vtiger_Request $request)
    {
        global $adb;
        $current_user = Users_Record_Model::getCurrentUserModel();
        $current_user_id = $current_user->getId();
        $sql = "SELECT\r\n            vtiger_crmentity.crmid,vtiger_crmentity.label,vtiger_crmentity.setype\r\n        FROM\r\n            `global_search_log`\r\n        INNER JOIN vtiger_crmentity ON vtiger_crmentity.crmid = global_search_log.crmid\r\n        LEFT JOIN global_search_modules ON global_search_modules.module = vtiger_crmentity.setype\r\n        WHERE\r\n            vtiger_crmentity.deleted = 0\r\n        AND userid = ?\r\n        ORDER BY\r\n            global_search_log.id DESC\r\n        LIMIT 15";
        $re = $adb->pquery($sql, array($current_user_id));
        if (0 < $adb->num_rows($re)) {
            while ($row = $adb->fetchByAssoc($re)) {
                $crmid = $row["crmid"];
                $label = $row["label"];
                $setype = $row["setype"];
                $records[] = array("id" => $crmid, "label" => $label, "module" => $setype);
            }
            $html = $this->getList($records, "logged");
            echo $html;
        }
    }
    public function getPhoneFields($module)
    {
        global $adb;
        $arrFields = array();
        $tabid = getTabid($module);
        $sql = "SELECT fieldname,tablename FROM `vtiger_field` WHERE uitype=? AND tabid=?";
        $rs = $adb->pquery($sql, array("11", $tabid));
        if (0 < $adb->num_rows($rs)) {
            while ($row = $adb->fetch_array($rs)) {
                $arrFields[$row["fieldname"]] = $row["tablename"];
            }
        }
        return $arrFields;
    }
    public function searchRecord(Vtiger_Request $request)
    {
        global $adb;
        global $vtiger_current_version;
        $current_user = Users_Record_Model::getCurrentUserModel();
        $search = $request->get("label");
        $search = trim($search);
        $sql = "SELECT * FROM global_search_method";
        $re = $adb->pquery($sql, array());
        if (0 < $adb->num_rows($re)) {
            $search_method = $adb->query_result($re, 0, "search_method");
            $limit_per_module = $adb->query_result($re, 0, "limit_per_module");
        }
        if (empty($search_method)) {
            $search_method = "contains";
        }
        if (empty($limit_per_module)) {
            $limit_per_module = 7;
        }
        $sql = "SELECT\r\n            *\r\n        FROM\r\n            `global_search_quick_search_settings`\r\n        LEFT JOIN global_search_modules ON global_search_modules.module = global_search_quick_search_settings.module\r\n        ORDER BY global_search_modules.sequence ASC;";
        $re = $adb->pquery($sql, array());
        if (0 < $adb->num_rows($re)) {
            $module_records = array();
            while ($row = $adb->fetchByAssoc($re)) {
                $search_module = $row["module"];
                $search_fields = $row["search_fields"];
                $show_fields = $row["show_fields"];
                $enabled = $row["enabled"];
                if ($enabled == 1) {
                    $user = Users_Record_Model::getCurrentUserModel();
                    $userPrivilegesModel = Users_Privileges_Model::getCurrentUserPrivilegesModel();
                    $moduleModel = Vtiger_Module_Model::getInstance($search_module);
                    $permission = $userPrivilegesModel->hasModulePermission($moduleModel->getId());
                    if ($permission) {
                        $moduleFieldList = $moduleModel->getFields();
                        $modulePhoneFields = $this->getPhoneFields($search_module);
                        $pagingModel = new Vtiger_Paging_Model();
                        $pagingModel->set("page", 1);
                        if (version_compare($vtiger_current_version, "7.0.0", "<")) {
                            $queryGenerator = new QueryGenerator($search_module, $user);
                        } else {
                            $queryGenerator = new EnhancedQueryGenerator($search_module, $user);
                        }
                        $queryFields = array();
                        $queryFields[] = "id";
                        if (!empty($search_fields)) {
                            $search_fields = explode(",", $search_fields);
                            foreach ($search_fields as $field) {
                                $field = explode(":", $field);
                                $queryFields[] = $field[2];
                            }
                        } else {
                            $sql_1 = "SELECT fieldname FROM `vtiger_field` WHERE tabid = (SELECT tabid FROM vtiger_tab WHERE name = '" . $search_module . "') AND headerfield = 1 AND presence <> 1;";
                            $re_1 = $adb->pquery($sql_1, array());
                            if (0 < $adb->num_rows($re_1)) {
                                while ($row_1 = $adb->fetchByAssoc($re_1)) {
                                    $queryFields[] = $row_1["fieldname"];
                                }
                            }
                        }
                        $searchKey = $search;
                        if ($searchKey != "") {
                            $queryGenerator->startGroup("");
                        }
                        $i = 0;
                        foreach ($queryFields as $name) {
                            if ($name == "id") {
                                $name = $queryGenerator->getSQLColumn("id");
                            }
                            $fieldModel = $moduleFieldList[$name];
                            if (empty($fieldModel)) {
                                continue;
                            }
                            $typeOfData = $fieldModel->get("typeofdata");
                            $typeOfData = explode("~", $typeOfData);
                            $typeOfData = $typeOfData[0];
                            if (in_array($name, array_keys($modulePhoneFields))) {
                                $searchKeyPhone = preg_replace("/[^A-Za-z0-9,]/", "", $searchKey);
                                if ($searchKeyPhone != "") {
                                    $phoneFields[] = $modulePhoneFields[$name] . "." . $name;
                                    if (0 < $i) {
                                        $queryGenerator->addConditionGlue("or");
                                    }
                                    if ($search_method == "contains") {
                                        $queryGenerator->addCondition($name, $searchKeyPhone, "c");
                                    } else {
                                        $queryGenerator->addCondition($name, $searchKeyPhone, "s");
                                    }
                                    $i++;
                                }
                            } else {
                                if (!empty($searchKey)) {
                                    if ($typeOfData == "D" || $typeOfData == "DT" || $typeOfData == "T") {
                                        $searchValue = DateTimeField::convertToDBFormat($searchKey);
                                        if (0 < $i) {
                                            $queryGenerator->addConditionGlue("or");
                                        }
                                        $queryGenerator->addCondition($name, $searchValue, "e");
                                        $i++;
                                    } else {
                                        if (($typeOfData == "N" || $typeOfData == "NN" || $typeOfData == "I") && is_numeric($searchKey)) {
                                            if (0 < $i) {
                                                $queryGenerator->addConditionGlue("or");
                                            }
                                            $queryGenerator->addCondition($name, $searchKey, "e");
                                            $i++;
                                        } else {
                                            if ($typeOfData != "N" && $typeOfData != "NN" && $typeOfData != "I") {
                                                if (0 < $i) {
                                                    $queryGenerator->addConditionGlue("or");
                                                }
                                                if ($search_method == "contains") {
                                                    $queryGenerator->addCondition($name, $searchKey, "c");
                                                } else {
                                                    $queryGenerator->addCondition($name, $searchKey, "s");
                                                }
                                                $i++;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        if ($searchKey != "") {
                            $queryGenerator->endGroup();
                        }
                        $customQuickSearchConditions = $moduleModel->customQuickSearchCondition;
                        if (!empty($customQuickSearchConditions)) {
                            foreach ($customQuickSearchConditions as $customCondition) {
                                $queryGenerator->addCondition($customCondition[0], $customCondition[1], $customCondition[2], $customCondition[3]);
                            }
                        }
                        $queryShowFields = array();
                        $queryShowFields[] = "id";
                        if (!empty($show_fields)) {
                            $show_fields = explode(",", $show_fields);
                            foreach ($show_fields as $field) {
                                $field = explode(":", $field);
                                $queryShowFields[] = $field[2];
                            }
                        } else {
                            $sql_2 = "SELECT fieldname FROM `vtiger_field` WHERE tabid = (SELECT tabid FROM vtiger_tab WHERE name = ?)\r\n                            AND headerfield = 1 AND presence <> 1 LIMIT 3;";
                            $re_2 = $adb->pquery($sql_2, array($search_module));
                            if (0 < $adb->num_rows($re_2)) {
                                while ($row_2 = $adb->fetchByAssoc($re_2)) {
                                    $queryShowFields[] = $row_2["fieldname"];
                                }
                            }
                        }
                        $queryGenerator->setFields(array_merge($queryShowFields, $queryFields));
                        $query = $queryGenerator->getQuery();
                        $query = str_replace("SELECT", "SELECT vtiger_crmentity.label, vtiger_crmentity.crmid,", $query);
                        if ($search_module == "Contacts") {
                            $str = "( vtiger_crmentity.label LIKE '%" . $search . "%') ";
                            if (in_array("firstname", $queryFields) && in_array("lastname", $queryFields)) {
                                $query = str_replace("( vtiger_contactdetails.firstname LIKE '%" . $search . "%') ", $str, $query);
                                $query = str_replace("or ( vtiger_contactdetails.lastname LIKE '%" . $search . "%') ", "", $query);
                            }
                        } else {
                            if ($search_module == "Leads") {
                                $str = "( vtiger_crmentity.label LIKE '%" . $search . "%') ";
                                if (in_array("firstname", $queryFields) && in_array("lastname", $queryFields)) {
                                    $query = str_replace("( vtiger_leaddetails.firstname LIKE '%" . $search . "%') ", $str, $query);
                                    $query = str_replace("or ( vtiger_leaddetails.lastname LIKE '%" . $search . "%') ", "", $query);
                                }
                            }
                        }
                        $query = str_replace("%" . trim($search) . "%", "%" . $search . "%", $query);
                        $startIndex = $pagingModel->getStartIndex();
                        $pageLimit = $pagingModel->getPageLimit();
                        $query .= " LIMIT " . $limit_per_module . " ";
                        $results = $adb->pquery($query, array());
                        $listViewContoller = new ListViewController($adb, $user, $queryGenerator);
                        $moduleFocus = CRMEntity::getInstance($search_module);
                        $listViewEntries = $listViewContoller->getListViewRecords($moduleFocus, $search_module, $results);
                        $list_record = array();
                        foreach ($listViewEntries as $recordId => $record) {
                            $crmid = $recordId;
                            $recordModel = Vtiger_Record_Model::getInstanceById($crmid);
                            $label = $recordModel->get("label");
                            $setype = $search_module;
                            $show_fields_value = array();
                            $search_fields_value = array();
                            foreach ($record as $field_name => $value) {
                                $value = preg_replace("/(<\\/[^>]+?>)(<[^>\\/][^>]*?>)/", "\$1 \$2", $value);
                                $value = strip_tags($value);
                                $fieldModel = $moduleFieldList[$field_name];
                                if (empty($fieldModel)) {
                                    continue;
                                }
                                if ($fieldModel->getFieldDataType() == "reference" && $value == "--") {
                                    $value = "";
                                }
                                if (in_array($field_name, $queryShowFields)) {
                                    $show_fields_value[] = $value;
                                }
                                if (in_array($field_name, $queryFields)) {
                                    $search_fields_value[] = $value;
                                }
                            }
                            $list_record[] = array("id" => $crmid, "label" => $label, "module" => $setype, "show_fields_value" => $show_fields_value, "search_fields_value" => $search_fields_value);
                        }
                        $sort_records = array();
                        foreach ($list_record as $record) {
                            $search_fields_value = $record["search_fields_value"];
                            foreach ($search_fields_value as $value) {
                                $patern_1 = "/^" . strtolower(trim($search)) . "[\\w\\W]*?/";
                                $patern_2 = "/[\\w\\W]*?" . strtolower(trim($search)) . "\\z/";
                                if (preg_match($patern_1, strtolower($value))) {
                                    $sort_records[1][] = $record;
                                    break;
                                }
                                if (preg_match($patern_2, strtolower($value))) {
                                    $sort_records[2][] = $record;
                                    break;
                                }
                                $sort_records[3][] = $record;
                                break;
                            }
                        }
                        array_push($module_records, $sort_records[1]);
                        array_push($module_records, $sort_records[2]);
                        array_push($module_records, $sort_records[3]);
                    }
                }
            }
        }
        $results = array();
        foreach ($module_records as $records) {
            if (count($records)) {
                foreach ($records as $record) {
                    array_push($results, $record);
                }
            }
        }
        $html = $this->getList($results, "", $search);
        echo $html;
    }
    public function getList($records, $type = "", $search = "")
    {
        global $adb;
        $html = "<ul class=\"dropdown-menu search_ajax_result\" style=\"top: 36px;left: -324px;width: 309px;overflow-x: auto;max-height: 600px;\">";
        if (0 < count($records)) {
            $module_name = "";
            foreach ($records as $item) {
                $sql = "SELECT\r\n                    appname,\r\n                    sequence\r\n                FROM\r\n                    `vtiger_app2tab`\r\n                WHERE\r\n                    tabid = (\r\n                        SELECT\r\n                            tabid\r\n                        FROM\r\n                            vtiger_tab\r\n                        WHERE\r\n                            `name` = '" . $item["module"] . "'\r\n                    )\r\n                AND visible = 1 ORDER BY sequence LIMIT 1;";
                $re = $adb->pquery($sql, array());
                if (0 < $adb->num_rows($re)) {
                    $appname = $adb->query_result($re, 0, "appname");
                }
                $subject = $item["label"];
                $show_fields_value = $item["show_fields_value"];
                if (count($show_fields_value)) {
                    foreach ($show_fields_value as $key => $val) {
                        if (empty($val)) {
                            unset($show_fields_value[$key]);
                        }
                    }
                }
                if (count($show_fields_value)) {
                    $show_fields_value = implode("&nbsp;&nbsp;<i style=\"font-size: 5px;\" class=\"fa fa-circle\"></i>&nbsp;&nbsp;", $show_fields_value);
                } else {
                    $show_fields_value = "";
                }
                $search_low = $search;
                $search_reg = "/" . $search_low . "/i";
                if (!empty($show_fields_value) && !empty($search) && preg_match($search_reg, $show_fields_value, $matches)) {
                    $value = $matches[0];
                    $replace = "<b style=\"color: #8b8b8b\">" . $value . "</b>";
                    $pos = strpos($show_fields_value, $value);
                    $lent = strlen($value);
                    $show_fields_value = substr_replace($show_fields_value, $replace, $pos, $lent);
                }
                if (!empty($search) && preg_match($search_reg, $subject, $matches)) {
                    $value = $matches[0];
                    $replace = "<b style=\"color: #15c\">" . $value . "</b>";
                    $pos = strpos($subject, $value);
                    $lent = strlen($value);
                    $subject = substr_replace($subject, $replace, $pos, $lent);
                }
                if ($type != "logged" && $module_name != "" && $module_name != $item["module"]) {
                    $html .= "<li><hr><li>";
                }
                $html .= "<li class=\"search-ajax-record\" style=\"margin-left: 0px; cursor: pointer;\" data-module=\"" . $item["module"] . "\" data-id=\"" . $item["id"] . "\" data-label=\"" . $item["label"] . "\" >\r\n                <a style=\"padding-top:3px;padding-bottom:3px;\" target=\"_blank\" >\r\n                    <div>\r\n                        <div onclick=\"record_to_log(this)\" data-record=\"" . $item["id"] . "\" data-url=\"index.php?module=" . $item["module"] . "&view=Detail&record=" . $item["id"] . "\" style=\"width: 90%; float: left\">\r\n                             <div class=\"app-" . $appname . "\" style=\"margin-top: 0px;float: left;text-align: center;vertical-align: middle;border-radius: 2px;width: 30px;height: 30px;margin-right: 10px;padding-top: 7px;" . ($appname != "" ? "color:#fff;" : "") . "\" title=\"" . vtranslate($item["module"], $item["module"]) . "\">\r\n                            <i style=\"font-size: 15px;\" class=\"vicon-" . strtolower($item["module"]) . "\" title=\"" . vtranslate($item["module"], $item["module"]) . "\"></i>\r\n                            </div> \r\n                            <div style=\"padding-top: 1px;padding-bottom: 1px;font-size: 12px;color: #15c;text-overflow: ellipsis !important;overflow: hidden;line-height: 1.2;\">" . vtranslate($subject, $item["module"]) . "<br><span class=\"gs-qs-secondrow\">" . ($search != "" ? $show_fields_value : vtranslate("SINGLE_" . $item["module"], $item["module"])) . "</span></div>\r\n                        </div>\r\n                        <div class=\"open-new-tab hidden\" onclick=\"record_to_log(this)\" data-record=\"" . $item["id"] . "\" data-url=\"index.php?module=" . $item["module"] . "&view=Detail&record=" . $item["id"] . "\" data-ridrect=\"_blank\" style=\"width: 10%;float:left;\">\r\n                            <div style=\"padding-top: 7px;padding-bottom: 1px;padding-left:15px;font-size: 12px;color: #15c;line-height: 1.1;\">\r\n                                &nbsp;&nbsp;<i class=\"fa fa-external-link\"></i>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"clearfix\"></div>\r\n                    </div>\r\n                </a>\r\n                </li>";
                $module_name = $item["module"];
            }
        } else {
            $html .= "<li><div style=\"padding-left: 20px;\">No records found</div></li>";
        }
        $html .= "</ul>";
        return $html;
    }
    public function getCountRecord(Vtiger_Request $request)
    {
        global $adb;
        global $vtiger_current_version;
        $debug = $request->get("debug");
        $search_results = array();
        $pagingModels = array();
        $record_comments = array();
        $response = new Vtiger_Response();
        $searchVals = explode(" ", $request->get("value"));
        $search_module = $request->get("search_module");
        $search_type = $request->get("search_type");
        $sql = "SELECT * FROM global_search_method";
        $re = $adb->pquery($sql, array());
        if (0 < $adb->num_rows($re)) {
            $search_method = $adb->query_result($re, 0, "search_method");
        }
        $searchQuery = "SELECT global_search_modules.*\r\n                FROM `global_search_modules`\r\n                INNER JOIN vtiger_tab ON vtiger_tab.`name`=global_search_modules.module\r\n                WHERE active='1' AND presence<>1 AND isentitytype = '1'";
        if ($search_module != "" && $search_module != "undefined") {
            $searchQuery .= " AND global_search_modules.module='" . $search_module . "'";
        }
        $searchQuery .= " ORDER BY global_search_modules.sequence";
        $rs = $adb->pquery($searchQuery, array());
        if (0 < $adb->num_rows($rs)) {
            while ($row = $adb->fetch_array($rs)) {
                $pagingModel = new Vtiger_Paging_Model();
                $pagingModel->set("page", "1");
                $queryFields = array();
                $search_module = $row["module"];
                if (in_array($search_module, array("ANCustomers", "ANPaymentProfile", "ANTransactions", "DuplicateCheckMerge"))) {
                    continue;
                }
                $presenceFields = $this->getPresenceFields($search_module);
                $user = Users_Record_Model::getCurrentUserModel();
                $userPrivilegesModel = Users_Privileges_Model::getCurrentUserPrivilegesModel();
                $moduleFocus = CRMEntity::getInstance($search_module);
                $moduleModel = Vtiger_Module_Model::getInstance($search_module);
                $permission = $userPrivilegesModel->hasModulePermission($moduleModel->getId());
                if ($permission) {
                    if (version_compare($vtiger_current_version, "7.0.0", "<")) {
                        $queryGenerator = new QueryGenerator($search_module, $user);
                    } else {
                        $queryGenerator = new EnhancedQueryGenerator($search_module, $user);
                    }
                    $referenceFieldInfoList = $queryGenerator->getReferenceFieldInfoList();
                    $referenceFieldList = $queryGenerator->getReferenceFieldList();
                    $modulePhoneFields = $this->getPhoneFields($search_module);
                    $moduleFieldList = $moduleModel->getFields();
                    $queryFields[] = "id";
                    $rsFields = $adb->pquery("SELECT * FROM `global_search_fields` WHERE module=? AND fieldname <> '' AND fieldname IS NOT NULL ORDER BY id", array($search_module));
                    $numRows = $adb->num_rows($rsFields);
                    if ($numRows == 0) {
                        $sql_default_view = "SELECT DISTINCT\r\n                            vtiger_cvcolumnlist.columnname AS fieldname\r\n                        FROM\r\n                            `vtiger_cvcolumnlist`\r\n                        INNER JOIN (\r\n                            SELECT\r\n                                *\r\n                            FROM\r\n                                vtiger_customview\r\n                            WHERE\r\n                                viewname = 'All' AND vtiger_customview.entitytype = '" . $search_module . "'\r\n                            ORDER BY\r\n                                cvid ASC\r\n                            LIMIT 1\r\n                        ) vtiger_customview ON vtiger_customview.cvid = vtiger_cvcolumnlist.cvid\r\n                        ORDER BY\r\n                            columnindex";
                        $rsFields = $adb->pquery($sql_default_view, array());
                        $numRows = $adb->num_rows($rsFields);
                    }
                    $i = 0;
                    $phoneFields = array();
                    if (0 < $numRows) {
                        $rowFields_array = array();
                        while ($row = $adb->fetch_array($rsFields)) {
                            $rowFields_array[] = $row;
                        }
                        $search_value = trim($request->get("value"));
                        if (strpos($search_value, ";") !== false && 1 < count(explode(";", $search_value))) {
                            $search_value = explode(";", $search_value);
                            $j = 0;
                            foreach ($search_value as $value) {
                                if (0 < $j) {
                                    $queryGenerator->addConditionGlue("and");
                                }
                                if (trim($value) != "") {
                                    $queryGenerator->startGroup("");
                                }
                                $k = 0;
                                foreach ($rowFields_array as $rowFields) {
                                    $fieldDetails = explode(":", $rowFields["fieldname"]);
                                    if (in_array($fieldDetails[2], $presenceFields)) {
                                        if (in_array($fieldDetails[2], $referenceFieldList) && count($referenceFieldInfoList[$fieldDetails[2]]) == 0) {
                                            continue;
                                        }
                                        $queryFields[] = $fieldDetails[2];
                                        if (empty($fieldDetails[2]) && $fieldDetails[1] == "crmid" && $fieldDetails[0] == "vtiger_crmentity") {
                                            $name = $queryGenerator->getSQLColumn("id");
                                        } else {
                                            $name = $fieldDetails[2];
                                        }
                                        $fieldModel = $moduleFieldList[$name];
                                        if (empty($fieldModel) || !$fieldModel->isViewableInDetailView()) {
                                            continue;
                                        }
                                        if (in_array($name, array_keys($modulePhoneFields))) {
                                            $searchKey = preg_replace("/[^A-Za-z0-9]/", "", trim($value));
                                            if ($searchKey != "") {
                                                $phoneFields[] = $modulePhoneFields[$name] . "." . $name;
                                                if (0 < $k) {
                                                    $queryGenerator->addConditionGlue("or");
                                                }
                                                $queryGenerator->addCondition($name, $searchKey, "c");
                                                $k++;
                                            }
                                        } else {
                                            $searchKey = trim($value);
                                            if (!empty($searchKey)) {
                                                if ($fieldDetails[4] == "D" || $fieldDetails[4] == "DT" || $fieldDetails[4] == "T") {
                                                    $searchValue = DateTimeField::convertToDBFormat($searchKey);
                                                    if (strtotime($searchValue)) {
                                                        if (0 < $k) {
                                                            $queryGenerator->addConditionGlue("or");
                                                        }
                                                        $queryGenerator->addCondition($name, $searchValue, "e");
                                                        $k++;
                                                    }
                                                } else {
                                                    if (($fieldDetails[4] == "N" || $fieldDetails[4] == "NN" || $fieldDetails[4] == "I") && is_numeric($searchKey)) {
                                                        if (0 < $k) {
                                                            $queryGenerator->addConditionGlue("or");
                                                        }
                                                        $queryGenerator->addCondition($name, $searchKey, "e");
                                                        $k++;
                                                    } else {
                                                        if ($fieldDetails[4] != "N" && $fieldDetails[4] != "NN" && $fieldDetails[4] != "I") {
                                                            if (0 < $k) {
                                                                $queryGenerator->addConditionGlue("or");
                                                            }
                                                            $queryGenerator->addCondition($name, $searchKey, "c");
                                                            $k++;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                if (trim($value) != "") {
                                    $queryGenerator->endGroup();
                                }
                                $j++;
                            }
                        } else {
                            if (trim($request->get("value")) != "") {
                                $queryGenerator->startGroup("");
                            }
                            foreach ($rowFields_array as $rowFields) {
                                $fieldDetails = explode(":", $rowFields["fieldname"]);
                                if (in_array($fieldDetails[2], $presenceFields)) {
                                    if (in_array($fieldDetails[2], $referenceFieldList) && count($referenceFieldInfoList[$fieldDetails[2]]) == 0) {
                                        continue;
                                    }
                                    $queryFields[] = $fieldDetails[2];
                                    if (empty($fieldDetails[2]) && $fieldDetails[1] == "crmid" && $fieldDetails[0] == "vtiger_crmentity") {
                                        $name = $queryGenerator->getSQLColumn("id");
                                    } else {
                                        $name = $fieldDetails[2];
                                    }
                                    $fieldModel = $moduleFieldList[$name];
                                    if (empty($fieldModel) || !$fieldModel->isViewableInDetailView()) {
                                        continue;
                                    }
                                    if (in_array($name, array_keys($modulePhoneFields))) {
                                        $searchKey = preg_replace("/[^A-Za-z0-9,]/", "", trim($request->get("value")));
                                        if ($searchKey != "") {
                                            $phoneFields[] = $modulePhoneFields[$name] . "." . $name;
                                            if (0 < $i) {
                                                $queryGenerator->addConditionGlue("or");
                                            }
                                            $queryGenerator->addCondition($name, $searchKey, "c");
                                            $i++;
                                        }
                                    } else {
                                        $searchKey = trim($request->get("value"));
                                        if (!empty($searchKey)) {
                                            if ($fieldDetails[4] == "D" || $fieldDetails[4] == "DT" || $fieldDetails[4] == "T") {
                                                $searchValue = DateTimeField::convertToDBFormat($searchKey);
                                                if (strtotime($searchValue)) {
                                                    if (0 < $i) {
                                                        $queryGenerator->addConditionGlue("or");
                                                    }
                                                    $queryGenerator->addCondition($name, $searchValue, "e");
                                                    $i++;
                                                }
                                            } else {
                                                if (($fieldDetails[4] == "N" || $fieldDetails[4] == "NN" || $fieldDetails[4] == "I") && is_numeric($searchKey)) {
                                                    if (0 < $i) {
                                                        $queryGenerator->addConditionGlue("or");
                                                    }
                                                    $queryGenerator->addCondition($name, $searchKey, "e");
                                                    $i++;
                                                } else {
                                                    if ($fieldDetails[4] != "N" && $fieldDetails[4] != "NN" && $fieldDetails[4] != "I") {
                                                        if (0 < $i) {
                                                            $queryGenerator->addConditionGlue("or");
                                                        }
                                                        $queryGenerator->addCondition($name, $searchKey, "c");
                                                        $i++;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            if (trim($request->get("value")) != "") {
                                $queryGenerator->endGroup();
                            }
                        }
                    }
                    if (!empty($search_type) && $search_type == "vt_standard") {
                        $search_params = $request->get("search_params");
                        if (!empty($search_params)) {
                            $search_params_str = json_encode($search_params);
                            if (empty($search_params[1])) {
                                unset($search_params[1]);
                            }
                            if (!is_array($search_params)) {
                                $search_params = urldecode($search_params);
                                $search_params = json_decode($search_params);
                                if (empty($search_params[1])) {
                                    unset($search_params[1]);
                                }
                            }
                            $advFilterList = Vtiger_Util_Helper::transferListSearchParamsToFilterCondition($search_params, $moduleModel);
                            if (is_array($advFilterList) && 0 < count($advFilterList)) {
                                vimport("~~/modules/CustomView/CustomView.php");
                                $customView = new CustomView($search_module);
                                $dateSpecificConditions = $customView->getStdFilterConditions();
                                foreach ($advFilterList as $groupindex => $groupcolumns) {
                                    $filtercolumns = $groupcolumns["columns"];
                                    if (0 < count($filtercolumns)) {
                                        $queryGenerator->startGroup("");
                                        foreach ($filtercolumns as $index => $filter) {
                                            $specialDateTimeConditions = Vtiger_Functions::getSpecialDateTimeCondtions();
                                            $nameComponents = explode(":", $filter["columnname"]);
                                            if (empty($nameComponents[2]) && $nameComponents[1] == "crmid" && $nameComponents[0] == "vtiger_crmentity") {
                                                $name = $queryGenerator->getSQLColumn("id");
                                            } else {
                                                $name = $nameComponents[2];
                                            }
                                            if (($nameComponents[4] == "D" || $nameComponents[4] == "DT") && in_array($filter["comparator"], $dateSpecificConditions)) {
                                                $filter["stdfilter"] = $filter["comparator"];
                                                $valueComponents = explode(",", $filter["value"]);
                                                if ($filter["comparator"] == "custom") {
                                                    $filter["startdate"] = DateTimeField::convertToDBFormat($valueComponents[0]);
                                                    $filter["enddate"] = DateTimeField::convertToDBFormat($valueComponents[1]);
                                                }
                                                $dateFilterResolvedList = $customView->resolveDateFilterValue($filter);
                                                $value[] = $queryGenerator->fixDateTimeValue($name, $dateFilterResolvedList["startdate"]);
                                                $value[] = $queryGenerator->fixDateTimeValue($name, $dateFilterResolvedList["enddate"], false);
                                                $queryGenerator->addCondition($name, $value, "BETWEEN");
                                            } else {
                                                if (($nameComponents[4] == "D" || $nameComponents[4] == "DT") && in_array($filter["comparator"], $specialDateTimeConditions)) {
                                                    $values = EnhancedQueryGenerator::getSpecialDateConditionValue($filter["comparator"], $filter["value"], $nameComponents[4], true);
                                                    $queryGenerator->addCondition($name, $values["date"], $values["comparator"]);
                                                } else {
                                                    $queryGenerator->addCondition($name, $filter["value"], $filter["comparator"]);
                                                }
                                            }
                                            $columncondition = $filter["column_condition"];
                                            if (!empty($columncondition)) {
                                                $queryGenerator->addConditionGlue($columncondition);
                                            }
                                        }
                                        $queryGenerator->endGroup();
                                        $groupConditionGlue = $groupcolumns["condition"];
                                        if (!empty($groupConditionGlue)) {
                                            $queryGenerator->addConditionGlue($groupConditionGlue);
                                        }
                                    }
                                }
                            }
                        }
                    }
                    $columnFieldMapping = $moduleModel->getColumnFieldMapping();
                    $queryFields_show = array();
                    $sql_fields_show = "SELECT\r\n                        *\r\n                    FROM\r\n                        `global_search_fields`\r\n                    WHERE\r\n                        module = '" . $search_module . "'\r\n                    AND fieldname_show <> ''\r\n                    AND fieldname_show IS NOT NULL\r\n                    ORDER BY\r\n                        id;";
                    $re_fields_show = $adb->pquery($sql_fields_show, array());
                    if (0 < $adb->num_rows($re_fields_show)) {
                        while ($row_fields_show = $adb->fetchByAssoc($re_fields_show)) {
                            $fieldDetails = explode(":", $row_fields_show["fieldname_show"]);
                            $queryFields_show[] = $fieldDetails[2];
                        }
                    }
                    if (!empty($queryFields_show)) {
                        $queryFields_show[] = "id";
                        $queryGenerator->setFields($queryFields_show);
                    } else {
                        $queryFields_show[] = "id";
                        $sql_default_view = "SELECT DISTINCT\r\n                            vtiger_cvcolumnlist.columnname AS fieldname\r\n                        FROM\r\n                            `vtiger_cvcolumnlist`\r\n                        INNER JOIN (\r\n                            SELECT\r\n                                *\r\n                            FROM\r\n                                vtiger_customview\r\n                            WHERE\r\n                                viewname = 'All' AND vtiger_customview.entitytype = '" . $search_module . "'\r\n                            ORDER BY\r\n                                cvid ASC\r\n                            LIMIT 1\r\n                        ) vtiger_customview ON vtiger_customview.cvid = vtiger_cvcolumnlist.cvid\r\n                        ORDER BY\r\n                            columnindex";
                        $rsFields = $adb->pquery($sql_default_view, array());
                        $numRows = $adb->num_rows($rsFields);
                        if (0 < $numRows) {
                            while ($row = $adb->fetch_array($rsFields)) {
                                $fieldDetails = $row["fieldname"];
                                $fieldDetails = explode(":", $fieldDetails);
                                $queryFields_show[] = $fieldDetails[2];
                            }
                        }
                        $queryGenerator->setFields($queryFields_show);
                    }
                    $listViewContoller = new ListViewController($adb, $user, $queryGenerator);
                    $headerFieldModels = array();
                    $headerFields = $listViewContoller->getListViewHeaderFields();
                    foreach ($headerFields as $fieldName => $webserviceField) {
                        if (in_array($fieldName, array_keys($moduleFieldList))) {
                            if ($webserviceField && !in_array($webserviceField->getPresence(), array(0, 2))) {
                                continue;
                            }
                            $headerFieldModels[$fieldName] = Vtiger_Field_Model::getInstance($fieldName, $moduleModel);
                        }
                    }
                    $search_results[$search_module]["listViewHeaders"] = $headerFieldModels;
                    if ($search_module == "Calendar") {
                        $queryGenerator->addCondition("activitytype", "Emails", "n", "AND");
                    }
                    $query = $queryGenerator->getQuery();
                    $query = str_replace("(.createdtime", "(createdtime", $query);
                    $query = str_replace("(.modifiedtime", "(modifiedtime", $query);
                    if (empty($search_type) && ($search_module == "Contacts" || $search_module == "Leads")) {
                        $query .= " OR (vtiger_crmentity.deleted = 0 AND vtiger_crmentity.label LIKE '%" . $search_value . "%')";
                    }
                    if (0 < count($phoneFields)) {
                        $position = stripos($query, " from ");
                        if ($position) {
                            $split = spliti(" from ", $query);
                            $whereQ = $split[1];
                            foreach ($phoneFields as $pfield) {
                                $whereQ = str_replace($pfield, "replace(replace(replace(replace(replace(replace(replace(" . $pfield . ", '+', ''), '-', ''), ')', ''),'(',''), '#', ''),'/',''),' ', '')", $whereQ);
                            }
                            $query = $split[0] . " FROM " . $whereQ;
                        }
                    }
                    $searchKey = trim($request->get("value"));
                    if (!empty($searchKey)) {
                        $position = stripos($query, " from ");
                        if ($position) {
                            $split = spliti(" where ", $query);
                            if ($search_module == "ModComments") {
                                $whereQ = "(" . $split[1] . " AND vtiger_modcomments.related_to > 0 AND vtiger_modcomments.related_to IS NOT NULL AND (SELECT crmid from vtiger_crmentity where crmid=vtiger_modcomments.related_to AND vtiger_crmentity.deleted = 0) IS NOT NULL)";
                            } else {
                                $whereQ = "(" . $split[1] . ")";
                            }
                            $convertedLead = "";
                            if ($search_module == "Leads") {
                                $convertedLead = " AND vtiger_leaddetails.converted = 0 ";
                            }
                            $whereQ .= " ";
                            $query = $split[0] . " where " . $whereQ . $convertedLead;
                        }
                    }
                    $startIndex = $pagingModel->getStartIndex();
                    $pageLimit = $pagingModel->getPageLimit();
                    $modules_sortby_label = array("Contacts", "Leads", "Accounts", "Vendors", "Products", "Services");
                    if (in_array($search_module, $modules_sortby_label)) {
                        $query .= " ORDER BY (vtiger_crmentity.label) ASC";
                    } else {
                        $query .= " ORDER BY vtiger_crmentity.modifiedtime DESC";
                    }
                    $keyword = $request->get("keyword");
                    if (!empty($keyword)) {
                        $keyword = explode(",", $keyword);
                        foreach ($keyword as $k => $item) {
                            $item = trim($item);
                            $item = preg_replace("/[^A-Za-z0-9]/", "", trim($item));
                            $keyword[$k] = $item;
                        }
                        $where = array();
                        $query_1 = explode("FROM", $query);
                        $query_1 = $query_1[0];
                        $query_1 = str_replace("SELECT", "", $query_1);
                        $query_1 = trim($query_1);
                        $query_1 = explode(",", $query_1);
                        $join = array();
                        $moduleModel = Vtiger_Module_Model::getInstance($search_module);
                        $module = Vtiger_Module::getInstance($search_module);
                        $table_index = $module->basetableid;
                        foreach ($query_1 as $field) {
                            $field = explode(".", $field);
                            $field = $field[1];
                            $field_with_as = explode("AS", $field);
                            if (1 < count($field_with_as)) {
                                $field = trim($field_with_as[1]);
                            }
                            if ($field != $table_index) {
                                $field_model = Vtiger_Field_Model::getInstance($field, $moduleModel);
                                if ($field_model) {
                                    if ($field_model->get("uitype") == 10 || $field_model->get("uitype") == 59 || $field_model->get("uitype") == 51) {
                                        $join[] = " LEFT JOIN vtiger_crmentity as vtiger_crmentity" . $field . " ON vtiger_crmentity" . $field . ".crmid = result." . $field . " ";
                                        $condition = array();
                                        foreach ($keyword as $item) {
                                            $condition[] = "vtiger_crmentity" . $field . ".label LIKE '%" . $item . "%' ";
                                        }
                                        $condition = implode(" OR ", $condition);
                                        $where[] = "(" . $condition . ")";
                                    } else {
                                        $condition = array();
                                        foreach ($keyword as $item) {
                                            $condition[] = "result." . $field . " LIKE '%" . $item . "%' ";
                                        }
                                        $condition = implode(" OR ", $condition);
                                        $where[] = "(" . $condition . ")";
                                    }
                                } else {
                                    $condition = array();
                                    foreach ($keyword as $item) {
                                        $condition[] = "result." . $field . " LIKE '%" . $item . "%' ";
                                    }
                                    $condition = implode(" OR ", $condition);
                                    $where[] = "(" . $condition . ")";
                                }
                            }
                        }
                        $query = "SELECT DISTINCT result.* FROM (" . $query . ") result";
                        if (!empty($join)) {
                            $join = implode(" ", $join);
                            $query .= $join;
                        }
                        $query .= " LEFT JOIN vtiger_modcomments ON vtiger_modcomments.related_to = result." . $table_index . " ";
                        if (!empty($where)) {
                            $where = implode(" OR ", $where);
                            $query .= " WHERE " . $where;
                        }
                        foreach ($keyword as $item) {
                            $query .= " OR vtiger_modcomments.commentcontent LIKE '%" . $item . "%' ";
                        }
                        $query_keyword_comment = $query;
                        $re_keyword_comment = $adb->pquery($query_keyword_comment, array());
                        if (0 < $adb->num_rows($re_keyword_comment)) {
                            while ($row_keyword_comment = $adb->fetchByAssoc($re_keyword_comment)) {
                                $record_id = $row_keyword_comment[$table_index];
                                $sql_comment = "SELECT\r\n                                    *\r\n                                FROM\r\n                                    `vtiger_modcomments`\r\n                                INNER JOIN vtiger_crmentity ON vtiger_crmentity.crmid = vtiger_modcomments.modcommentsid\r\n                                WHERE\r\n                                    vtiger_modcomments.related_to = " . $record_id . "\r\n                                AND vtiger_crmentity.deleted = 0 AND ";
                                $condition = array();
                                foreach ($keyword as $item) {
                                    $condition[] = " vtiger_modcomments.commentcontent LIKE '%" . $item . "%' ";
                                }
                                $condition = implode(" OR ", $condition);
                                $sql_comment .= " (" . $condition . ") ";
                                $re_comment = $adb->pquery($sql_comment, array());
                                if (0 < $adb->num_rows($re_comment)) {
                                    $comments = array();
                                    while ($row_comment = $adb->fetchByAssoc($re_comment)) {
                                        $comments[] = $row_comment;
                                    }
                                    $record_comments[$record_id] = $comments;
                                }
                            }
                        }
                    }
                    $countQuery = "";
                    $position = stripos($query, " from ");
                    if ($position) {
                        $split = spliti(" from ", $query);
                        $splitCount = count($split);
                        if (!empty($keyword)) {
                            $countQuery = "SELECT count(DISTINCT result." . $table_index . ") AS count ";
                        } else {
                            $countQuery = "SELECT count(*) AS count ";
                        }
                        for ($i = 1; $i < $splitCount; $i++) {
                            $countQuery = $countQuery . " FROM " . $split[$i];
                        }
                    }
                    $countResult = $adb->pquery($countQuery, array());
                    $totalResults = $adb->query_result($countResult, 0, "count");
                    $response->setResult(array("data" => $totalResults));
                    $response->emit();
                }
            }
        } else {
            $response->setError();
            $response->emit();
        }
    }
    public function getPresenceFields($module)
    {
        global $adb;
        $arrFields = array();
        $tabid = getTabid($module);
        $sql = "SELECT fieldname FROM `vtiger_field` WHERE tabid=? AND presence IN (0,2)";
        $rs = $adb->pquery($sql, array($tabid));
        if (0 < $adb->num_rows($rs)) {
            while ($row = $adb->fetch_array($rs)) {
                $arrFields[] = $row["fieldname"];
            }
        }
        return $arrFields;
    }
}

?>