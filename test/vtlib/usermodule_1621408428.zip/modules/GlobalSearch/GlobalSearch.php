<?php

require_once "data/CRMEntity.php";
require_once "data/Tracker.php";
require_once "vtlib/Vtiger/Module.php";
class GlobalSearch extends CRMEntity
{
    /**
     * Invoked when special actions are performed on the module.
     * @param String Module name
     * @param String Event Type (module.postinstall, module.disabled, module.enabled, module.preuninstall)
     */
    public function vtlib_handler($modulename, $event_type)
    {
        if ($event_type == "module.postinstall") {
            self::addWidgetTo();
            self::iniData();
            self::fixVTIssues();
            self::resetValid();
            self::updateQuickSearchStatusByGlobalSearch();
        } else {
            if ($event_type == "module.disabled") {
                self::removeWidgetTo();
            } else {
                if ($event_type == "module.enabled") {
                    self::addWidgetTo();
                    self::fixVTIssues();
                } else {
                    if ($event_type == "module.preuninstall") {
                        self::removeWidgetTo();
                        self::removeValid();
                    } else {
                        if ($event_type == "module.preupdate") {
                            self::addTable();
                        } else {
                            if ($event_type == "module.postupdate") {
                                self::addTable();
                                self::removeWidgetTo();
                                self::addWidgetTo();
                                self::fixVTIssues();
                                self::resetValid();
                                self::updateQuickSearchStatusByGlobalSearch();
                            }
                        }
                    }
                }
            }
        }
    }
    public function addTable()
    {
        global $adb;
        $sql = "CREATE TABLE `global_search_method` (\r\n\t\t\t`search_method`  varchar(50) NULL\r\n\t\t\t)\r\n\t\t\t;";
        $adb->pquery($sql, array());
        $sql = "ALTER TABLE `global_search_method`\r\n\t\t\tADD COLUMN `limit_per_module`  int NULL AFTER `search_method`;";
        $adb->pquery($sql, array());
        $sql = "SELECT * FROM global_search_method";
        $re = $adb->pquery($sql, array());
        if (0 < $adb->num_rows($re)) {
            $search_method = $adb->query_result($re, 0, "search_method");
            $limit_per_module = $adb->query_result($re, 0, "limit_per_module");
            if (empty($search_method)) {
                $sql = "UPDATE global_search_method SET search_method = 'contains';";
                $adb->pquery($sql, array());
            }
            if (empty($limit_per_module)) {
                $sql = "UPDATE global_search_method SET limit_per_module = 7;";
                $adb->pquery($sql, array());
            }
        } else {
            $sql = "INSERT INTO global_search_method(search_method,limit_per_module) VALUE('contains',7)";
            $adb->pquery($sql, array());
        }
        $sql = "CREATE TABLE `global_search_quick_search_settings` (\r\n\t\t\t`id`  int NOT NULL AUTO_INCREMENT,\r\n\t\t\t`module`  varchar(255) NULL ,\r\n\t\t\t`search_fields`  tinytext NULL ,\r\n\t\t\t`show_fields`  tinytext NULL ,\r\n\t\t\t`enabled`  int NULL ,\r\n\t\t\tPRIMARY KEY (`id`)\r\n\t\t\t);";
        $adb->pquery($sql, array());
    }
    public static function iniData()
    {
        global $adb;
        $allModules = Vtiger_Module_Model::getSearchableModules();
        $inactiveModules = array("Calendar", "ModComments", "Events", "Tasks");
        $searchModules = array_keys($allModules);
        $ignoreModules = array("PSTemplates", "VTEPayments");
        foreach ($searchModules as $module) {
            $sql_1 = "SELECT tabid, customized FROM `vtiger_tab` WHERE `name` = '" . $module . "';";
            $results = $adb->pquery($sql_1, array());
            if (0 < $adb->num_rows($results)) {
                $customized = $adb->query_result($results, 0, "customized");
                $tabid = $adb->query_result($results, 0, "tabid");
            }
            $active = 1;
            if (in_array($module, $inactiveModules) || $customized == 1) {
                $active = 0;
            }
            if (!in_array($module, $ignoreModules)) {
                $adb->pquery("INSERT INTO `global_search_modules` (`module`, `active`,sequence) VALUES (?, ?, ?)", array($module, $active, $tabid));
            }
            $sql = "SELECT fieldname FROM `vtiger_entityname` WHERE modulename = ?;";
            $re = $adb->pquery($sql, array($module));
            if (0 < $adb->num_rows($re)) {
                $fieldname = $adb->query_result($re, 0, "fieldname");
                $fieldname = explode(",", $fieldname);
                $viewcolumnname = array();
                $moduleModel = Vtiger_Module_Model::getInstance($module);
                foreach ($fieldname as $field) {
                    if ($field) {
                        $field_model = Vtiger_Field_Model::getInstance($field, $moduleModel);
                        if ($field_model) {
                            $viewcolumnname[] = $field_model->getCustomViewColumnName();
                        }
                    }
                }
                $viewcolumnname = implode(",", $viewcolumnname);
            }
            $adb->pquery("INSERT INTO `global_search_quick_search_settings` (`module`, `search_fields`,show_fields,enabled) VALUES (?, ?, ?,?)", array($module, $viewcolumnname, "", $active));
            if ($module == "ModComments") {
                $sql = "INSERT INTO `global_search_fields` ( `module`, `fieldname`) VALUES ('ModComments', 'vtiger_modcomments:commentcontent:commentcontent:ModComments_Comment:V');";
                $adb->pquery($sql, array());
                $sql = "INSERT INTO `global_search_fields` ( `module`, `fieldname`) VALUES ('ModComments', 'vtiger_crmentity:smownerid:assigned_user_id:ModComments_Assigned_To:V');";
                $adb->pquery($sql, array());
                $sql = "INSERT INTO `global_search_fields` ( `module`, `fieldname`) VALUES ('ModComments', 'vtiger_modcomments:related_to:related_to:ModComments_Related_To:V');";
                $adb->pquery($sql, array());
                $sql = "INSERT INTO `global_search_fields` ( `module`, `fieldname`) VALUES ('ModComments', 'vtiger_crmentity:createdtime:createdtime:ModComments_Created_Time:DT');";
                $adb->pquery($sql, array());
            }
        }
    }
    public static function fixVTIssues()
    {
        global $adb;
        global $dbconfig;
        $adb->pquery("UPDATE `vtiger_cvcolumnlist` SET `columnname`='vtiger_products:commissionrate:commissionrate:Products_Commission_Rate:N' WHERE (`columnname`='vtiger_products:commissionrate:commissionrate:Products_Commission_Rate:V');", array());
        $adb->pquery("UPDATE `vtiger_cvcolumnlist` SET `columnname`='vtiger_products:qtyinstock:qtyinstock:Products_Quantity_In_Stock:N' WHERE (`columnname`='vtiger_products:qtyinstock:qtyinstock:Products_Quantity_In_Stock:V');", array());
        $adb->pquery("UPDATE `vtiger_cvcolumnlist` SET `columnname`='vtiger_products:qty_per_unit:qty_per_unit:Products_Qty/Unit:N' WHERE `columnname`='vtiger_products:qty_per_unit:qty_per_unit:Products_Qty/Unit:V';", array());
        $adb->pquery("UPDATE `vtiger_cvcolumnlist` SET `columnname`='vtiger_products:unit_price:unit_price:Products_Unit_Price:N' WHERE `columnname`='vtiger_products:unit_price:unit_price:Products_Unit_Price:V';", array());
        $adb->pquery("UPDATE `vtiger_cvcolumnlist` SET `columnname`='vtiger_quotes:total:hdnGrandTotal:Quotes_Total:N' WHERE `columnname`='vtiger_quotes:total:hdnGrandTotal:Quotes_Total:V';", array());
        $adb->pquery("UPDATE `vtiger_cvcolumnlist` SET `columnname`='vtiger_purchaseorder:total:hdnGrandTotal:PurchaseOrder_Total:N' WHERE `columnname`='vtiger_purchaseorder:total:hdnGrandTotal:PurchaseOrder_Total:V';", array());
        $adb->pquery("UPDATE `vtiger_cvcolumnlist` SET `columnname`='vtiger_salesorder:total:hdnGrandTotal:SalesOrder_Total:N' WHERE `columnname`='vtiger_salesorder:total:hdnGrandTotal:SalesOrder_Total:V';", array());
        $adb->pquery("UPDATE `vtiger_cvcolumnlist` SET `columnname`='vtiger_invoice:total:hdnGrandTotal:Invoice_Total:N' WHERE `columnname`='vtiger_invoice:total:hdnGrandTotal:Invoice_Total:V';", array());
        $adb->pquery("UPDATE `vtiger_cvcolumnlist` SET `columnname`='vtiger_campaign:expectedrevenue:expectedrevenue:Campaigns_Expected_Revenue:N' WHERE `columnname`='vtiger_campaign:expectedrevenue:expectedrevenue:Campaigns_Expected_Revenue:V';", array());
        $adb->pquery("UPDATE `vtiger_cvcolumnlist` SET `columnname`='vtiger_pbxmanager:totalduration:totalduration:PBXManager_Total_Duration:N' WHERE `columnname`='vtiger_pbxmanager:totalduration:totalduration:PBXManager_Total_Duration:V';", array());
        $sql = "SELECT character_set_name, collation_name\r\n                FROM information_schema.`COLUMNS` C\r\n                WHERE table_schema = '" . $dbconfig["db_name"] . "'\r\n                  AND table_name = 'vtiger_tab'\r\n                  AND column_name = 'name';";
        $rsCharset = $adb->pquery($sql, array());
        $character_set_name = $adb->query_result($rsCharset, 0, "character_set_name");
        $collation_name = $adb->query_result($rsCharset, 0, "collation_name");
        $adb->pquery("ALTER TABLE `global_search_modules`\r\nMODIFY COLUMN `module`  varchar(250) CHARACTER SET '" . $character_set_name . "' COLLATE '" . $collation_name . "' NOT NULL DEFAULT '' ", array());
        $adb->pquery("ALTER TABLE `global_search_quick_search_settings`\r\nMODIFY COLUMN `module`  varchar(250) CHARACTER SET '" . $character_set_name . "' COLLATE '" . $collation_name . "' NOT NULL DEFAULT '' ", array());
        $inactiveModules = array("Calendar", "ModComments", "Events", "Tasks");
        $allModules = Vtiger_Module_Model::getSearchableModules();
        $searchModules = array_keys($allModules);
        $ignoreModules = array("PSTemplates", "VTEPayments");
        foreach ($searchModules as $module) {
            $sql_1 = "SELECT tabid, customized FROM `vtiger_tab` WHERE `name` = '" . $module . "';";
            $results = $adb->pquery($sql_1, array());
            if (0 < $adb->num_rows($results)) {
                $customized = $adb->query_result($results, 0, "customized");
                $tabid = $adb->query_result($results, 0, "tabid");
            }
            $active = 1;
            if (in_array($module, $inactiveModules) || $customized == 1) {
                $active = 0;
                $adb->pquery("UPDATE `global_search_modules` SET `active` = ? WHERE `module` = ? AND active <> 1", array($active, $module));
            }
            if (!in_array($module, $ignoreModules)) {
                $adb->pquery("UPDATE `global_search_modules` SET `sequence` = ? WHERE `module` = ?", array($tabid, $module));
            }
        }
    }
    /**
     * Add header script to other module.
     * @return unknown_type
     */
    public static function addWidgetTo()
    {
        global $adb;
        global $vtiger_current_version;
        $widgetType = "HEADERSCRIPT";
        $widgetName = "GlobalSearchJs";
        if (version_compare($vtiger_current_version, "7.0.0", "<")) {
            $template_folder = "layouts/vlayout";
        } else {
            $template_folder = "layouts/v7";
        }
        $link = $template_folder . "/modules/GlobalSearch/resources/GlobalSearch.js";
        include_once "vtlib/Vtiger/Module.php";
        $moduleNames = array("GlobalSearch");
        foreach ($moduleNames as $moduleName) {
            $module = Vtiger_Module::getInstance($moduleName);
            if ($module) {
                $module->addLink($widgetType, $widgetName, $link);
            }
        }
        $blockid = 4;
        $res = $adb->pquery("SELECT blockid FROM `vtiger_settings_blocks` WHERE label='LBL_OTHER_SETTINGS'", array());
        if (0 < $adb->num_rows($res)) {
            while ($row = $adb->fetch_row($res)) {
                $blockid = $row["blockid"];
            }
        }
        $adb->pquery("UPDATE vtiger_settings_field_seq SET id=(SELECT MAX(fieldid) FROM vtiger_settings_field)", array());
        $max_id = $adb->getUniqueID("vtiger_settings_field");
        $adb->pquery("INSERT INTO `vtiger_settings_field` (`fieldid`, `blockid`, `name`, `description`, `linkto`, `sequence`) VALUES (?, ?, ?, ?, ?, ?)", array($max_id, $blockid, "Global Search", "Settings area for Global Search", "index.php?module=GlobalSearch&parent=Settings&view=Settings", $max_id));
    }
    public static function removeWidgetTo()
    {
        global $adb;
        global $vtiger_current_version;
        $widgetType = "HEADERSCRIPT";
        $widgetName = "GlobalSearchJs";
        if (version_compare($vtiger_current_version, "7.0.0", "<")) {
            $template_folder = "layouts/vlayout";
            $vtVersion = "vt6";
            $linkVT6 = $template_folder . "/modules/GlobalSearch/resources/GlobalSearch.js";
        } else {
            $template_folder = "layouts/v7";
            $vtVersion = "vt7";
        }
        $link = $template_folder . "/modules/GlobalSearch/resources/GlobalSearch.js";
        include_once "vtlib/Vtiger/Module.php";
        $moduleNames = array("GlobalSearch");
        foreach ($moduleNames as $moduleName) {
            $module = Vtiger_Module::getInstance($moduleName);
            if ($module) {
                $module->deleteLink($widgetType, $widgetName, $link);
                if ($vtVersion != "vt6") {
                    $module->deleteLink($widgetType, $widgetName, $linkVT6);
                }
            }
        }
        $adb->pquery("DELETE FROM vtiger_settings_field WHERE `name` = ?", array("Global Search"));
    }
    public static function resetValid()
    {
        global $adb;
        $adb->pquery("DELETE FROM `vte_modules` WHERE module=?;", array("GlobalSearch"));
        $adb->pquery("INSERT INTO `vte_modules` (`module`, `valid`) VALUES (?, ?);", array("GlobalSearch", "0"));
    }
    public static function removeValid()
    {
        global $adb;
        $adb->pquery("DELETE FROM `vte_modules` WHERE module=?;", array("GlobalSearch"));
    }
    public static function updateQuickSearchStatusByGlobalSearch()
    {
        global $adb;
        $query = "SELECT module,active FROM global_search_modules WHERE active = 1";
        $result = $adb->pquery($query, array());
        if (0 < $adb->num_rows($result)) {
            while ($row = $adb->fetchByAssoc($result)) {
                $module = $row["module"];
                $status = $row["active"];
                $adb->pquery("UPDATE global_search_quick_search_settings SET enabled=? WHERE module=?", array($status, $module));
            }
        }
    }
}

?>